// Extracted production webpack module 61400; require dependencies are supplied by webpack.
module.exports = (e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),t.TraderProcessor=void 0;const a=n(82125),i=n(32024),r=n(22869),o=n(26774),s=n(27988),l=n(26735),c=n(44669),d=n(98003),u=n(51477),p=n(39021),g=n(92659),m=n(47751),f=n(17790),h=n(19719);class _{static _instance;interval=null;pauseInterval=null;controllerInstance=null;isStarted;isFirstRun;isOperationInProgress;statsProcessor;traderSettings;traderData;enhancerData;botController;notifier;listCheckCount;cancellationToken=null;waveLock=null;constructor(){this.isStarted=!1,this.isFirstRun=!0,this.isOperationInProgress=!1,this.statsProcessor=p.StatsFactory.instance.getProcessor();const e=i.InMemoryStore.instance;this.traderSettings=e.get("traderSettings"),this.traderData=e.get("traderData"),this.enhancerData=e.get("enhancerData"),this.notifier=o.NotificationOrchestrator.instance,this.botController=new g.BotController,this.listCheckCount=0}static get instance(){return this._instance||(this._instance=new _),this._instance}setControllerInstance(e){this.controllerInstance=e}getControllerInstance(){return this.controllerInstance}async runActions(e){if(this.isOperationInProgress)return;if(this.traderData.cache.filter.changesMade)return void this.showUnSavedChanges();await(0,m.runAutoActionsMiddlewares)();const t=this.controllerInstance?.viewmodel.searchCriteria;if(!t)return;services.Notification.clearAll(),this.statsProcessor.updateTempStat("nextExecutionTime",e);const n=d.TransferFactory.instance.getTransferOrchestrator();this.cancellationToken={isCancelled:!1},this.isOperationInProgress=!0;try{const cfg=this.traderSettings.searchSetting;
const auto=cfg.autoFindNewest===true;
const configured=Math.max(1,Math.min(500,Math.floor(Number(cfg.startingSearchPage)||1)));
const nav=this.__fcNav||(this.__fcNav=(function(){
const LO=3540,HI=3600,MAXP=500;
const clampP=p=>Math.max(1,Math.min(MAXP,Math.floor(Number(p))||1));
const load=()=>{try{const v=Number(localStorage.getItem("fcFreshAnchor"));return v>=1?v:0}catch(_){return 0}};
const save=p=>{try{localStorage.setItem("fcFreshAnchor",String(p))}catch(_){}};
function init(auto,configured){
 const saved=auto?load():0;
 const start=clampP(auto?(saved||configured||1):configured);
 return {page:start,auto,configured,probe:false,pendingJump:auto&&start>1,
  anchor:0,lo:0,hi:MAXP+1,gallop:0,lastDir:0,jumpsOk:auto?null:false,jumpFails:0,maxValid:0,lastGood:0,
  emptyStreak:0,blockedStreak:0,watchChecks:0,altChecks:0,seqStalls:0,clearCache:false,cacheToggles:0,phase:"start",cls:"-"};
}
function classify(d){
 if(!d.length)return"none";
 if(d.some(v=>v>=LO&&v<=HI))return"fresh";
 if(Math.max(...d)<LO)return"early";
 if(Math.min(...d)>HI)return"late";
 return"gap";
}
// Plan the next non-probe page while hunting for the band. dir=+1: band is on a later page, -1: earlier.
function seek(s,from,dir){
 if(s.lastDir!==dir)s.gallop=0;
 s.lastDir=dir;
 if(dir>0)s.lo=Math.max(s.lo,from);else s.hi=Math.min(s.hi,from);
 if(s.lo>=s.hi){s.lo=dir>0?from:0;s.hi=dir>0?MAXP+1:from}   // drift contradicted old bounds
 if(s.hi-s.lo<=1){                                              // band sits between two adjacent pages
  s.phase="band-empty";s.altChecks++;
  s.pendingJump=false;
  return clampP(s.lo>=1?(s.altChecks%2?s.lo:s.hi):s.hi);
 }
 let next;
 if(s.jumpsOk===false)next=from+dir;
 else if(s.lo>=1&&s.hi<=MAXP)next=Math.floor((s.lo+s.hi)/2);    // both bounds real: bisect
 else{s.gallop=Math.min(s.gallop+1,5);next=from+dir*(1<<(s.gallop-1))}  // 1,2,4,8,16 pages
 next=clampP(Math.max(s.lo+1,Math.min(s.hi-1,next)));
 s.pendingJump=Math.abs(next-from)>1;
 s.phase=dir>0?"seek-forward":"seek-back";
 return next;
}
function step(s,req,items,durs,warn){
 const wasProbe=s.probe,wasJump=s.pendingJump;
 s.probe=false;s.pendingJump=false;
 const retry=()=>{s.page=req;s.probe=wasProbe;s.pendingJump=wasJump};
 const backToAnchor=()=>clampP(s.anchor||s.lastGood||1);
 s.cls="-";
 if(items===null){                       // EA error or middleware block, NOT an empty page
  s.blockedStreak++;s.phase="request-blocked";retry();
  if(s.blockedStreak===3)warn("3 blocked searches in a row on page "+req+". Check Search Result Threshold (set blank/0) and the Trader log for EA errors.");
  return s.page;
 }
 s.blockedStreak=0;
 if(items.length===0){
  s.cls="empty";
  if(wasProbe){s.phase="probe-empty";s.emptyStreak=0;s.page=backToAnchor();return s.page}
  s.emptyStreak++;
  if(s.emptyStreak<(wasJump?2:3)){s.phase="empty-retry";retry();return s.page}
  s.emptyStreak=0;
  if(wasJump){                            // a multi-page jump returned nothing
   s.jumpFails++;s.gallop=0;
   if(s.jumpsOk===true)s.hi=Math.min(s.hi,req);   // jumps known to work => target is past the end of the list
   else if(s.jumpFails>=2){s.jumpsOk=false;warn("Direct page jumps failed twice. Falling back to one page at a time.")}
   s.phase="jump-failed";s.page=clampP(s.lastGood||1);return s.page;
  }
  if(req>s.maxValid){                     // first page past the last known-valid one
   s.seqStalls++;s.phase="edge-stall";s.gallop=0;
   if(s.seqStalls===1||s.seqStalls%10===0)warn("Page "+req+" returned nothing 3x right after page "+s.maxValid+" had results. Either the list really ends at page "+s.maxValid+" or EA is refusing to paginate. Navigation can't fix the second case: narrow the filters so the 59-60 min listings land on early pages.");
   if(s.cacheToggles<2){s.clearCache=!s.clearCache;s.cacheToggles++;warn("Experiment: clear market cache before each search = "+s.clearCache)}
   s.page=clampP(s.maxValid||1);return s.page;
  }
  s.maxValid=Math.max(0,req-1);s.phase="list-shrank";s.page=clampP(req-1);return s.page;
 }
 s.emptyStreak=0;
 if(wasJump)s.jumpsOk=true;
 s.lastGood=req;s.maxValid=Math.max(s.maxValid,req);
 s.cls=classify(durs);
 const newest=durs.length?Math.max(...durs):0,oldest=durs.length?Math.min(...durs):0;
 if(wasProbe){                           // neighbour probe: never navigate from it, always go home
  s.phase="probe-return";s.page=backToAnchor();return s.page;
 }
 if(s.cls==="fresh"){
  s.anchor=req;save(req);s.lo=0;s.hi=MAXP+1;s.gallop=0;s.lastDir=0;
  s.phase="watch";s.watchChecks++;
  const off=[0,newest<=HI?1:0,0,oldest>=LO?-1:0][s.watchChecks%4];
  const tgt=clampP(req+off);
  if(off&&tgt!==req){s.probe=true;s.phase="watch+probe";s.page=tgt}else s.page=req;
  return s.page;
 }
 if(s.cls==="early"){s.page=seek(s,req,1);return s.page}
 if(s.cls==="late"){s.page=seek(s,req,-1);return s.page}
 s.anchor=req;s.phase="in-gap";s.page=req;    // band falls inside this page's span but no listing is in it right now
 return s.page;
}
return {init,step,clampP,LO,HI};
})());
let state=this.__fcFreshNavigation;
if(!state||state.configured!==configured||state.auto!==auto){state=this.__fcFreshNavigation=nav.init(auto,configured)}
const requestedPage=nav.clampP(state.page);
this.traderData.cache.nextPageNumber=requestedPage;
if(state.clearCache&&requestedPage>1){try{services.Item.clearTransferMarketCache()}catch(_){}}
let e=await n.searchMarket(t,requestedPage);
const items=Array.isArray(e)?e:null;
const durations=items?.map(item=>Number(item?.getAuctionData?.()?.expires)).filter(v=>Number.isFinite(v))||[];
const fresh=durations.some(v=>v>=nav.LO&&v<=nav.HI);
nav.step(state,requestedPage,items,durations,m=>console.warn("[FC Fresh Pages v6] "+m));
this.traderData.cache.nextPageNumber=state.page;
console.info("[FC Fresh Pages v6] requested="+requestedPage+" returned="+(items?.length??"BLOCKED")+" min="+(durations.length?Math.min(...durations):0)+" max="+(durations.length?Math.max(...durations):0)+" class="+state.cls+" fresh="+fresh+" phase="+state.phase+" next="+state.page+" anchor="+state.anchor+" jumpsOk="+state.jumpsOk+" bounds="+state.lo+"-"+state.hi);
// Keep purchase pipeline restricted to listings with at least 59 minutes remaining.
e=items?items.filter(item=>{const seconds=Number(item?.getAuctionData?.()?.expires);return Number.isFinite(seconds)&&seconds>=3540&&seconds<=3600}):[];
if(e){const t=await n.handleTransferResults(e,this.traderSettings.safeSetting,this.cancellationToken);t?.length&&await n.handleWonItems(t)}const i=await this.checkBotState(),{tlWlCheckCycle:r}=this.statsProcessor.getTempStats();i||(this.listCheckCount+=1,this.listCheckCount%r||(this.statsProcessor.updateTempStat("tlWlCheckCycle",(0,a.getRandomNumberInRange)(2,5)),await n.handleTransferList(),await n.handleWatchList()))}catch(err){console.error("[FC Fresh Pages] Trader search failed",err)}this.isOperationInProgress=!1}async checkBotState(){const e=await this.botController.checkIfStopRequired();if(e)return this.stop(),e;const t=await this.botController.checkIfPauseRequired();return t&&this.pause(),t}setInitialValues(){this.setStopValues(),this.setPauseValues()}setPauseValues(){const{safeSetting:{pauseCycle:e,pauseFor:t}}=this.traderSettings,{stats:{searchCount:n}}=this.traderData;this.statsProcessor.updateTempStat("pauseCycle",(n||0)+(0,a.getRandomNumberInRange)(...e)),this.statsProcessor.updateTempStat("pauseFor",(0,a.getRandomNumberInRange)(...t)),this.resetPageNumber()}setStopValues(){const{safeSetting:{stopAfter:e}}=this.traderSettings;this.statsProcessor.updateStat("botStartTime",Date.now()),this.statsProcessor.updateTempStat("stopAfter",(0,a.getRandomNumberInRange)(e?.[0]||60,e?.[1]||120)),this.resetPageNumber()}resetPageNumber(){const{cache:e}=this.traderData;const auto=this.traderSettings.searchSetting.autoFindNewest===true;const start=auto?1:Math.max(1,Math.min(500,Math.floor(Number(this.traderSettings.searchSetting.startingSearchPage)||1)));if(!this.isStarted){this.__fcFreshNavigation=null;e.nextPageNumber=start}else e.nextPageNumber=this.__fcFreshNavigation?.page||start}async start(){if(this.isStarted||!this.verifyUserAccess())return;this.isFirstRun&&this.statsProcessor.updateStat("firstStartTime",Date.now()),this.isFirstRun=!1;const e=(0,a.find)(".ut-navigation-container-view--content");e&&(e.scrollTop=e.scrollHeight),this.isStarted=!0,this.enhancerData.isTraderRunning=!0;const{safeSetting:{waitTime:t}}=this.traderSettings;this.interval=f.TimerFactory.instance.getTimer(this.runActions.bind(this),...t),this.interval.run(),navigator.wakeLock?.request("screen").then((e=>{this.waveLock=e})),this.statsProcessor.start(),this.notifier.notifyAll({message:(0,c.translate)("abStarted"),type:r.ExternalNotificationType.STARTED}),this.setInitialValues(),this.controllerInstance?.toggleElementsState(!1)}stop(){this.interval?.stop(),this.pauseInterval?.stop(),this.statsProcessor.stop(),this.controllerInstance?.toggleElementsState(!0),this.enhancerData.isTraderRunning=!1,this.cancellationToken&&(this.cancellationToken.isCancelled=!0),this.isStarted&&(this.isStarted=!1,this.notifier.notifyAll({message:(0,c.translate)("abStopped"),type:r.ExternalNotificationType.STOPPED}),u.Logger.writeToLog((0,c.translate)("abStopped")),this.waveLock?.release().then((()=>{this.waveLock=null})))}pause(){const{safeSetting:{pauseFor:e}}=this.traderSettings;this.cancellationToken&&(this.cancellationToken.isCancelled=!0),this.interval?.stop(),this.pauseInterval=f.TimerFactory.instance.getTimer(this.resume.bind(this),...e);const t=this.pauseInterval.run(!1);this.statsProcessor.updateTempStat("isPaused",!0),this.statsProcessor.updateTempStat("nextExecutionTime",t),this.notifier.notify((0,c.translate)("abPaused"),"ui"),u.Logger.writeToLog((0,c.translate)("abPaused"))}resume(){this.pauseInterval?.stop(),this.setPauseValues();const{safeSetting:{waitTime:e}}=this.traderSettings;this.interval=f.TimerFactory.instance.getTimer(this.runActions.bind(this),...e),this.interval.run(),this.statsProcessor.updateTempStat("isPaused",!1),this.notifier.notify((0,c.translate)("abResumed"),"ui"),u.Logger.writeToLog((0,c.translate)("abResumed"))}showUnSavedChanges(){(0,s.showPopUp)({title:(0,c.translate)("unsavedChangeTitle"),message:(0,c.translate)("unsavedWarn"),onSelect:async e=>{this.stop(),107===e&&await(this.controllerInstance?.promptAndSaveFilter())&&this.start()},options:[{labelEnum:107},{labelEnum:enums.UIDialogOptions.CANCEL}],type:l.PopupType.ALERT,id:"popup_ab_filter_unsaved"})}verifyUserAccess(){const{tradeAccess:e}=services.User.getUser();if(e!==TradeAccessLevel.ALLOWED){const t=h.accessMessages.get(e)??"tile.disabled.transfersUnlockAccess";return u.Logger.writeToLog((0,s.getLocalization)().localize(t),l.UINotificationTypeEnum.NEGATIVE),!1}return!0}}t.TraderProcessor=_};
