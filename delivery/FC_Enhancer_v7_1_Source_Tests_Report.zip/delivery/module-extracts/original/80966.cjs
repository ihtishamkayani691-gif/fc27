// Extracted production webpack module 80966; require dependencies are supplied by webpack.
module.exports = (e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),t.setCurrentPageNumber=void 0;const a=n(32024);t.setCurrentPageNumber=async(e,t)=>t(e)};
