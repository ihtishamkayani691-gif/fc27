// Extracted production webpack module 83195; require dependencies are supplied by webpack.
module.exports = function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.observableToPromise=void 0,t.observableToPromise=e=>new Promise((t=>{e.observe(this,((e,{data:n,success:a,error:i,response:r})=>{e.unobserve(this),t(a?{success:a,data:r??n}:{success:a,data:n,error:i?.code})}))}))};
