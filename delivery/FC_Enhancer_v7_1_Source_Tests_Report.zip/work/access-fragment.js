// The starting page is an access probe, never an assumed returned page.
// Learn offset stride from observed page-1/page-2 requests (21 results can overlap by 1).
const transportKeys=new Set(['offset','count','start','num','page','pageindex','pagenumber']);
const isTransport=key=>transportKeys.has(key.replace(/^_+/,'').toLowerCase());
const semantic=criteria=>Object.fromEntries(Object.entries(criteria).filter(([key,value])=>!isTransport(key)&&typeof value!=='function'));
t.semantic=semantic;
const changedKeys=(before,after)=>[...new Set([...Object.keys(before),...Object.keys(after)])].filter(key=>JSON.stringify(stable(before[key]))!==JSON.stringify(stable(after[key]))).map(key=>key.replace(/[^a-zA-Z0-9_]/g,'').slice(0,40)).filter(Boolean);
const observedOffset=wire=>(wire.transport==='xhr'||wire.transport==='fetch')&&wire.status>=200&&wire.status<300&&typeof wire.offset==='number';
function selectSequential(state,reason){
 state.accessStage='DISCOVERY';state.access='sequential-fallback';state.page=1;state.phase='RECOVERING';state.reason=reason;
 state.discoveryBudget=state.configuredBudget;state.scanVisited.clear();state.scanDirection=0;state.seen.clear();state.empty=0;
}
function selectStart(state){
 state.accessStage='DISCOVERY';state.access='direct-probe-validated';state.discoveryBudget=state.configuredBudget;
 state.scanVisited.clear();state.scanDirection=0;state.reason='direct-probe-offset-matches-calibration';
}
t.process=(state,req,items,wire)=>{
 const stage=state.accessStage;
 if(stage==='PROBE_START'){
  const expected=state.baseOffset+(state.configuredStart-1)*state.stride;
  const baseline=[...state.seen.values()].map(value=>value.sig);
  const sig=Array.isArray(items)?items.map(item=>String(item?.getAuctionData?.()?.tradeId??item?.id??'')).sort().join(','):'';
  if(!Array.isArray(items)||!items.length||!observedOffset(wire)||wire.offset!==expected||baseline.includes(sig)){
   selectSequential(state,!items?.length?'direct-probe-empty-or-end-fallback':baseline.includes(sig)?'direct-probe-replayed-baseline-fallback':'direct-probe-offset-unverified-fallback');return;
  }
  selectStart(state);
 }
 t.advance(state,req,items);
 if(state.stopped||state.anchor||!items?.length)return;
 if(stage==='BASELINE'){
  state.baseOffset=observedOffset(wire)?wire.offset:null;state.baselineWire=wire;
  state.accessStage='CALIBRATE';state.page=2;state.phase='VALIDATING_ACCESS';state.reason='calibrate-service-page-2-before-start-probe';
 }else if(stage==='CALIBRATE'){
  const stride=state.baseOffset!==null&&observedOffset(wire)?wire.offset-state.baseOffset:0;
  if(stride>0){state.stride=stride;state.accessStage='PROBE_START';state.page=state.configuredStart;state.phase='VALIDATING_ACCESS';state.reason='probe-configured-start-using-observed-offset-stride';}
  else{
   state.accessStage='DISCOVERY';state.access='sequential-fallback';state.discoveryBudget=state.configuredBudget;
   state.reason='no-observable-offset-calibration-continue-sequential';
   if(state.scanVisited.size>=state.discoveryBudget){state.stopped=true;state.phase='STOPPED';state.reason='discovery-page-budget-exhausted';}
  }
 }
};
