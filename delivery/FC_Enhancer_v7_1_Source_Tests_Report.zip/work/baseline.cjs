const {test}=require('node:test');
const assert=require('node:assert/strict');
const {load,moduleExports}=require('./bundle-loader.cjs');
const file=__dirname+'/../original/js/main.js';
const {modules}=load(file,{localStorage:{getItem:()=>null,setItem(){}}});
test('v6 production randomizer reproduces 200,250,300,0 cycle',async()=>{
 const prices=[];const store={traderSettings:{searchSetting:{useRandomMinBuy:true,randomMinBuy:300}},traderData:{cache:{filter:{currentFilter:'scream'},minPriceByFilter:new Map([['scream',{minBuyPrice:150}]])}}};
 const {randomizeMinBidMinBuy}=moduleExports(modules,85462,{32024:{InMemoryStore:{instance:{get:k=>store[k]}}},27988:{getNextStepValue:x=>x?x+50:150}});
 for(let i=0;i<4;i++){const data={};await randomizeMinBidMinBuy({data},e=>{prices.push(e.data.minBuy)});}
 assert.deepEqual(prices,[200,250,300,0]);
});
test('v6 actual runActions starts at unverified 30; 30/31 empty states have no terminal state',async()=>{
 const deps={};for(const id of [82125,32024,22869,26774,27988,26735,44669,98003,51477,39021,92659,47751,17790,19719])deps[id]={};
 deps[47751].runAutoActionsMiddlewares=async()=>{};
 deps[98003].TransferFactory={instance:{getTransferOrchestrator:()=>({searchMarket:async()=>[],handleTransferResults:async()=>[]})}};
 const {modules:ms}=load(file,{localStorage:{getItem:()=>null,setItem(){}},services:{Notification:{clearAll(){}}}});
 const C=moduleExports(ms,61400,deps).TraderProcessor;
 const p=Object.create(C.prototype);Object.assign(p,{traderSettings:{searchSetting:{autoFindNewest:true,startingSearchPage:30},safeSetting:{}},traderData:{cache:{filter:{},nextPageNumber:1}},controllerInstance:{viewmodel:{searchCriteria:{}}},statsProcessor:{updateTempStat(){},getTempStats:()=>({tlWlCheckCycle:100})},checkBotState:async()=>false,listCheckCount:0});
 await p.runActions(10);assert.equal(p.__fcFreshNavigation.page,30);
 const nav=p.__fcNav;
 for(const req of [30,31]){const state=nav.init(true,req);for(let i=0;i<100;i++)nav.step(state,req,[],[],()=>{});assert.equal(state.stopped,undefined);assert.notEqual(state.phase,'STOPPED');}
 const state=nav.init(true,30);nav.step(state,30,[{}],[10],()=>{});assert.equal(state.jumpsOk,true);assert.equal(state.lastGood,30);
});
