from pathlib import Path
import shutil,re,json,difflib
root=Path(__file__).resolve().parent.parent
original=root/'original';patched=root/'patched'
shutil.copytree(original,patched,dirs_exist_ok=True)
s=(original/'js/main.js').read_text()
def replace(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old))
 s=s.replace(old,new)
replace('var e,t,n,a={','var e,t,n,a={99007:'+ (root/'work/fresh-module.js').read_text().strip()+',')
start=s.index('try{const cfg=this.traderSettings.searchSetting;')
end=s.index('if(e){const t=await n.handleTransferResults',start)
s=s[:start]+'''try{const freshOutcome=await(0,fresh.run)(this,t,n,message=>u.Logger.writeToLog(message));
let e=freshOutcome.items;
if(freshOutcome.stop)this.stop();
if(this.cancellationToken?.isCancelled)e=[];
'''+s[end:]
replace('g=n(92659),m=n(47751),f=n(17790),h=n(19719);class _','g=n(92659),m=n(47751),f=n(17790),h=n(19719),fresh=n(99007);class _')
# stop/restart invalidate state, do not retain anchors across filters or sessions.
replace('stop(){this.interval?.stop(),this.pauseInterval?.stop()','stop(){this.__fcFreshNavigation=null;this.interval?.stop(),this.pauseInterval?.stop()')
replace('catch(err){console.error("[FC Fresh Pages] Trader search failed",err)}','catch(err){u.Logger.writeToLog("[Fresh] mode=STOPPED reason=unhandled-search-exception buying=DISABLED");this.stop()}')
replace('t.randomizeMinBidMinBuy=async(e,t)=>{const{data:n}=e,','t.randomizeMinBidMinBuy=async(e,t)=>{if(fresh.isFresh(e.data))return t(e);const{data:n}=e,')
replace('t.randomizeMinBidMinBuy=void 0;const a=n(32024),i=n(27988),r=', 't.randomizeMinBidMinBuy=void 0;const fresh=n(99007),a=n(32024),i=n(27988),r=')
# Avoid enhancer result filtering/sorting and hidden automatic purchase side path for scoped fresh searches.
replace('services.Item.searchTransferMarket=function(i,l,...c){if(','services.Item.searchTransferMarket=function(i,l,...c){if(fresh.isFresh(i))return e.call(this,i,l,...c);if(')
replace('s=n(57684);t.transferSearchOverride=', 's=n(57684),fresh=n(99007);t.transferSearchOverride=')
# Hard safety interlock in TEST build: every service-level bid throws before calling EA.
replace('t.transferSearchOverride=()=>{const e=services.Item.searchTransferMarket,','t.transferSearchOverride=()=>{const noBid=function(){fresh.blockPurchase();throw new Error("FC v7.1 TEST: buying and bidding disabled")};services.Item.bid=noBid;if(typeof UTItemService!=="undefined")UTItemService.prototype.bid=noBid;const e=services.Item.searchTransferMarket,')
# Existing price/safety middleware remains intact; service interlock blocks execution.

replace('label:"Search Page Limit"','label:"Search Page Limit (pages per discovery)"')
# Replace only the background request module; keep regular callers' array interface.
start=s.index('65757:(e,t,n)=>{');end=s.index(',18707:',start)
s=s[:start]+'65757:'+(root/'work/search-module.js').read_text().strip()+s[end:]
(patched/'js/main.js').write_text(s)
manifest=json.loads((patched/'manifest.json').read_text());manifest['version']='27.0.1.5';manifest['version_name']='v7.1 Starting Page and Criteria TEST - buying disabled';manifest['name']='FC27 Enhancer v7.1 Pagination TEST (NO BUYING)';(patched/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'delivery/changes.diff').write_text(''.join(difflib.unified_diff((original/'js/main.js').read_text().splitlines(True),s.splitlines(True),fromfile='original/js/main.js',tofile='patched/js/main.js'))+''.join(difflib.unified_diff((original/'manifest.json').read_text().splitlines(True),(patched/'manifest.json').read_text().splitlines(True),fromfile='original/manifest.json',tofile='patched/manifest.json')))

# Preserve an unfiltered snapshot before the modern application's hidden-item filter.
index=(original/'js/index.js').read_text()
needle='const{items:o}=s.data;IXe(o);const l=RXe(o);'
assert index.count(needle)==1
index=index.replace(needle,'const{items:o}=s.data;globalThis[Symbol.for("fcEnhancer.fresh.v7")]?.captureRaw(t,o);IXe(o);const l=RXe(o);')
(patched/'js/index.js').write_text(index)
with (root/'delivery/changes.diff').open('a') as out:
 out.write(''.join(difflib.unified_diff((original/'js/index.js').read_text().splitlines(True),index.splitlines(True),fromfile='original/js/index.js',tofile='patched/js/index.js')))
# Preserve original CRLF bytes and missing-final-newline markers in an applicable patch.
import subprocess
parts=[]
for name in ['js/main.js','js/index.js','manifest.json']:
 result=subprocess.run(['diff','-u','--label','a/'+name,'--label','b/'+name,str(original/name),str(patched/name)],capture_output=True)
 assert result.returncode==1
 parts.append(result.stdout)
(root/'delivery/changes.diff').write_bytes(b''.join(parts))
shutil.copyfile(root/'delivery/LIVE_TEST.md',patched/'AUTOFIND_V7_1_README.md')

old_readme=patched/'AUTOFIND_V7_README.md'
if old_readme.exists():old_readme.unlink()
