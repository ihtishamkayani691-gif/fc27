// Passive, bounded observation only. Never changes requests or reads bodies/headers.
// A matching concurrent request makes correlation ambiguous; no server page is inferred.
let active=null,installed=false;
const wireByCriteria=new WeakMap();
const inspectURL=value=>{
 try{
  const url=new URL(String(value),globalThis.location?.href||'https://www.ea.com/');
  if(!/transfermarket/i.test(url.pathname))return null;
  const fields={};
  for(const key of ['start','offset','num','count','page','pageIndex']){
   const value=url.searchParams.get(key);
   if(value!==null&&/^\d{1,9}$/.test(value))fields[key]=Number(value);
  }
  return fields;
 }catch{return null}
};
const observe=(criteria,fields,transport)=>{
 if(!criteria||!fields)return null;
 const wire=wireByCriteria.get(criteria);if(!wire)return null;
 const entry={fields,transport,status:'unknown'};wire.push(entry);return entry;
};
function installObserver(){
 if(installed)return;installed=true;
 if(typeof XMLHttpRequest!=='undefined'){
  const proto=XMLHttpRequest.prototype,open=proto.open,send=proto.send,meta=new WeakMap();
  proto.open=function(method,url,...rest){meta.set(this,inspectURL(url));return open.call(this,method,url,...rest)};
  proto.send=function(...args){const entry=observe(active,meta.get(this),'xhr');if(entry)this.addEventListener('loadend',()=>{entry.status=this.status||'unknown'},{once:true});return send.apply(this,args)};
 }
 if(typeof globalThis.fetch==='function'){
  const fetch=globalThis.fetch;
  globalThis.fetch=function(input,...rest){
   const entry=observe(active,inspectURL(input?.url??input),'fetch');
   const response=fetch.call(this,input,...rest);
   if(entry)response.then(r=>{entry.status=r.status},()=>{});
   return response;
  };
 }
}
t.capture=async(criteria,call)=>{
 installObserver();wireByCriteria.set(criteria,[]);
 const previous=active;active=criteria;
 try{return await call()}finally{active=previous}
};
t.wire=criteria=>{
 const entries=wireByCriteria.get(criteria)||[];
 if(entries.length!==1)return{offset:'unknown',params:'unknown',status:'unknown',transport:entries.length?'ambiguous':'cache-or-unobserved'};
 const entry=entries[0];return {offset:entry.fields.start??entry.fields.offset??'unknown',params:Object.entries(entry.fields).map(([k,v])=>k+':'+v).join(',')||'unknown',status:entry.status,transport:entry.transport};
};
