from pathlib import Path
import subprocess,sys,json,zipfile,hashlib,shutil
root=Path(__file__).resolve().parent.parent
out=root/'delivery'
logs=[]
for name in ['baseline.cjs','regression.cjs']:
 run=subprocess.run(['node',str(root/'work'/name)],text=True,capture_output=True)
 logs.append(f'$ node work/{name}\n{run.stdout}{run.stderr}\nexit={run.returncode}\n')
 if run.returncode:sys.exit('Test failed: '+name)
(out/'TEST_RESULTS.txt').write_text('\n'.join(logs))
checks=[]
for p in sorted((root/'patched').rglob('*.js')):
 run=subprocess.run(['node','--check',str(p)],text=True,capture_output=True)
 checks.append({'file':str(p.relative_to(root/'patched')),'syntax_exit':run.returncode})
 if run.returncode:sys.exit(run.stderr)
manifest=json.loads((root/'patched/manifest.json').read_text())
paths=[manifest['background']['service_worker'],*manifest['icons'].values()]
for script in manifest['content_scripts']:paths+=script['js']
for group in manifest['web_accessible_resources']:paths+=group['resources']
for path in paths:assert (root/'patched'/path).is_file(),path
zip_path=out/'FC_Enhancer_v7_1_Pagination_Fix_TEST.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted((root/'patched').rglob('*')):
  if p.is_file():z.write(p,p.relative_to(root/'patched').as_posix())
with zipfile.ZipFile(zip_path)as z:
 assert z.testzip()is None
 assert 'manifest.json'in z.namelist()
 for name in z.namelist():assert z.read(name)==(root/'patched'/name).read_bytes()
original=root/'original';patched=root/'patched'
changed=[str(p.relative_to(patched))for p in patched.rglob('*')if p.is_file() and (not(original/p.relative_to(patched)).exists()or p.read_bytes()!=(original/p.relative_to(patched)).read_bytes())]
assert sorted(changed)==['AUTOFIND_V7_1_README.md','js/index.js','js/main.js','manifest.json'],changed
summary={'syntax_checks':checks,'manifest_resources_checked':len(paths),'zip_crc':'passed','zip_root_manifest':'passed','zip_contents_match_tested_files':True,'changed_files':changed,'extension_zip_sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'live_EA_verified':False,'chrome_loaded':False}
(out/'VERIFICATION.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
# Bundle original input, final production files and self-contained reproducible evidence.
evidence=out/'FC_Enhancer_v7_1_Source_Tests_Report.zip'
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['original','previous','patched','work']:
  for p in sorted((root/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(root).as_posix())
 for p in sorted(out.rglob('*')):
  if p.is_file()and p.suffix!='.zip':z.write(p,'delivery/'+p.relative_to(out).as_posix())
with zipfile.ZipFile(evidence)as z:assert z.testzip()is None
print('Evidence archive CRC passed')
