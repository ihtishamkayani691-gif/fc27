// Extracted production webpack module 55503; require dependencies are supplied by webpack.
module.exports = (e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),t.increaseFilterSearchCount=void 0;const a=n(32024);t.increaseFilterSearchCount=async(e,t)=>{const n=a.InMemoryStore.instance,{cache:{filter:i}}=n.get("traderData");return i.currentFilterRunCount+=1,t(e)}};
