// Reuse the production-path regression harness without registering/rerunning its suite.
globalThis.FC_TRACE_ONLY=true;
const {harness,recoveryFixture,liveItems,previous71}=require('./regression.cjs');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const traces=[];
 const capture=(name,h)=>traces.push({name,evidence:'MOCKED EA responses; actual extension Trader, filter loop and request adapter executed',pages:h.requests.map(r=>r.page),stopped:!h.p.isStarted,logs:h.logs.filter(line=>line.includes('[Fresh]')),databaseReads:h.loads});
 const oldStable=recoveryFixture({bundle:previous71});await oldStable.run(9);capture('v7.1 observed prefix extends sequentially with stable single SCREAM',oldStable);
 const oldRotating=recoveryFixture({bundle:previous71,filter:{currentFilter:'SCREAM',selectedFilters:['SCREAM','OTHER'],noOfTimesRange:[1,1]}});await oldRotating.run(8);capture('v7.1 real filter rotation repeatedly resets context before discovery',oldRotating);
 const oldConcurrent=recoveryFixture({bundle:previous71});await Promise.all([oldConcurrent.cycle(),oldConcurrent.cycle()]);capture('v7.1 overlapping cycle race',oldConcurrent);
 const fixed=recoveryFixture();await fixed.run(24);assert.deepEqual(fixed.requests.slice(0,7).map(r=>r.page),[1,2,20,1,2,3,4]);assert.ok(fixed.eligible.some(i=>i.getAuctionData().expires===3559));capture('v7.2 failed jump then sequential warmup, fresh page20, monitoring',fixed);
 const watchdog=recoveryFixture();await watchdog.run(4);for(let i=0;i<20&&watchdog.p.isStarted;i++){watchdog.p.__fcFreshNavigation.page=i%2?2:1;await watchdog.cycle()}assert.equal(watchdog.p.isStarted,false);capture('v7.2 watchdog catches deliberately forced discovery cycle',watchdog);
 const filename=path.join(__dirname,'../delivery/TRACE_EVIDENCE.json');fs.writeFileSync(filename,JSON.stringify(traces,null,2)+'\n');console.log('Captured five labeled mocked production traces:',filename);
})().catch(error=>{console.error(error);process.exitCode=1});
