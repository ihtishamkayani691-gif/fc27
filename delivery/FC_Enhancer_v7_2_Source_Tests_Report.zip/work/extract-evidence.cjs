const fs=require('node:fs');const path=require('node:path');const {load}=require('./bundle-loader.cjs');
const root=path.resolve(__dirname,'..');const ids=[61400,65757,33147,83195,1098,85462,4364,65685,3434,80966,30501,71446,57684,93519,875,7520,50379,90689,47751,17820,78017,55503,99007];
let mapping='build\tfile\tmodule\tline\tzero_based_character_offset\n';
for(const build of ['original','baseline-v71','patched']){
 const file=path.join(root,build,'js/main.js'),source=fs.readFileSync(file,'utf8'),{modules}=load(file);
 const out=path.join(root,'delivery','module-extracts',build);fs.mkdirSync(out,{recursive:true});
 for(const id of ids){if(!modules[id])continue;const match=source.match(new RegExp('(?:^|[,{])'+id+':(?=\\(|function|//)'));if(!match)throw Error('No module location '+id);const marker=match.index+match[0].indexOf(id+':');mapping+=`${build}\tjs/main.js\t${id}\t${source.slice(0,marker).split('\n').length}\t${marker}\n`;fs.writeFileSync(path.join(out,id+'.cjs'),'// Extracted production webpack module '+id+'; require dependencies are supplied by webpack.\nmodule.exports = '+modules[id].toString()+';\n');}
 const index=fs.readFileSync(path.join(root,build,'js/index.js'),'utf8');
 const start=index.indexOf('CXe=')+4,end=index.indexOf(',kXe=',start);fs.writeFileSync(path.join(out,'index-CXe.cjs'),'// Extracted modern production market wrapper.\nmodule.exports = '+index.slice(start,end)+';\n');mapping+=`${build}\tjs/index.js\tCXe\t${index.slice(0,start).split('\n').length}\t${start}\n`;
}
fs.writeFileSync(path.join(root,'delivery/SOURCE_LOCATIONS.tsv'),mapping);
// Unrelated main webpack modules must be identical, without regenerating vendor/dependency bundles.
const before=load(path.join(root,'original/js/main.js')).modules,after=load(path.join(root,'patched/js/main.js')).modules;
const changed=Object.keys(after).filter(id=>!before[id]||String(before[id])!==String(after[id]));
const expected=['875','30501','50379','61400','65757','85462','99007'].sort();if(JSON.stringify(changed.sort())!==JSON.stringify(expected))throw Error('Unexpected changed modules: '+changed);
console.log('Changed main modules:',changed.join(', '));

const old71=load(path.join(root,'baseline-v71/js/main.js')).modules;const changes71=Object.keys(after).filter(id=>!old71[id]||String(old71[id])!==String(after[id])).sort();const expected71=['875','30501','61400','65757','99007'].sort();if(JSON.stringify(changes71)!==JSON.stringify(expected71))throw Error('Unexpected incremental changes '+changes71);console.log('Incremental changed modules:',changes71.join(', '));
