(e,t,n)=>{
Object.defineProperty(t,'__esModule',{value:true});
const utils=n(82125),localize=n(44669),logger=n(51477),filters=n(17820),fresh=n(99007);
t.switchFilterIfRequired=async(event,next)=>{
 const data=event.params.data,cache=data.cache,filter=cache.filter;
 if(fresh.filterRotationDecision(data,event.params.settings)!=='allow')return next(event);
 if(!filter.noOfTimesToRun)filter.noOfTimesToRun=utils.getRandomNumberInRange(...filter.noOfTimesRange);
 if(filter.noOfTimesToRun&&filter.selectedFilters.length>0&&filter.currentFilterRunCount>=filter.noOfTimesToRun){
  const current=filter.currentFilter,index=filter.selectedFilters.indexOf(current);
  const choice=filter.runSequentially?(index+1)%filter.selectedFilters.length:utils.getRandomNumberInRange(0,filter.selectedFilters.length-1);
  const selected=filter.selectedFilters[choice];
  filter.currentFilterRunCount=0;filter.noOfTimesToRun=0;
  if(selected===current&&event.params.settings.searchSetting.autoFindNewest){fresh.noteFilterDecision(data,'same-filter-retained');return next(event)}
  filter.currentFilter=selected;cache.nextPageNumber=1;
  fresh.noteFilterDecision(data,'875.switchFilterIfRequired:genuine-filter-load');
  logger.Logger.writeToLog(localize.translate('switchFilter',{filterName:filter.currentFilter}));
  await filters.FilterHandler.instance.loadFilter(filter.currentFilter);
 }
 return next(event);
};
}
