const test=globalThis.FC_TRACE_ONLY?()=>{}:require('node:test').test;
const assert=require('node:assert/strict');
const {load,moduleExports}=require('./bundle-loader.cjs');
const file=__dirname+'/../patched/js/main.js';
const item=(id,expires)=>({id,getAuctionData:()=>({tradeId:String(id),expires,buyNowPrice:100})});
function harness(responses,options={}) {
 const logs=[],requests=[],eligible=[],loads=[],requestObjects=[];
 const settings={searchSetting:{autoFindNewest:true,startingSearchPage:1,searchResultPageLimit:39,useRandomMinBuy:true,randomMinBuy:300,...options.search},buySetting:{searchResultThreshold:21,...options.buy},safeSetting:{}};
 const data={cache:{filter:{currentFilter:'scream',selectedFilters:[],currentFilterRunCount:0,noOfTimesToRun:0,noOfTimesRange:[4,4],runSequentially:true,...options.filter},nextPageNumber:1,minPriceByFilter:new Map()}};
 const store={traderSettings:settings,traderData:data,enhancerSettings:{multiRarities:new Set(),searchSortField:'buy'},enhancerData:{}};
 const services={Notification:{clearAll(){}},Item:{clearTransferMarketCache(){},bid(){throw Error('Native bid must never execute')}}};
 const {modules,context}=load(options.bundle||file,{structuredClone,URL,services,...options.globals,localStorage:{getItem(){throw Error('Stale storage must not be read')},setItem(){throw Error('must not persist anchors')}}});
 const stubs={32024:{InMemoryStore:{instance:{get:k=>store[k]}}},27988:{getLocalization:()=>({}),getNextStepValue:x=>x?x+50:150},22869:{ExternalNotificationType:{STOPPED:"STOPPED"}},51477:{Logger:{writeToLog:x=>logs.push(x),writeSearchResultsToLog:(items,page,criteria)=>logs.push('Found '+items.length+' page '+page+' minBuy '+criteria.minBuy)}},26735:{UINotificationTypeEnum:{NEUTRAL:1}},44669:{translate:k=>k}};
 stubs[71446]={filterResult:items=>items};
 const cache={};
 const real=new Set([99007,85462,1098,4364,3434,65685,65757,30501]);
 if(options.productionLoop)for(const id of [875,47751,55503,17820])real.add(id);
 const noOp={buyPriceValidator:async(e,next)=>next(e),enhancerSettingValidator:async(e,next)=>next(e),getPlayersByrating:async(e,next)=>next(e),ratingValidator:async(e,next)=>next(e),updateSearchCount:async(e,next)=>next(e),increaseFilterSearchCount:async(e,next)=>next(e),setCurrentPageNumber:async(e,next)=>next(e),resetEnhancerDataRating:async(e,next)=>next(e),getRealTimePriceForResults:async(e,next)=>next(e)};
 for(const id of [58104,94697,5152,85472,33077,55503,80966,31476,7864])if(!real.has(id))stubs[id]=noOp;
 stubs[9514]={runMiddlewares:async(input,chain)=>{const dispatch=async(i,e)=>i<chain.length?chain[i](e,v=>dispatch(i+1,v)):{response:true};return dispatch(0,input)}};
 stubs[31679]={runErrorSearchMiddlewares:async()=>{}};
 stubs[13808]={searchTransferMarket:async(criteria,page)=>{
  requests.push({page,criteria:structuredClone(criteria)});requestObjects.push(criteria);
  const value=await (typeof responses==='function'?responses(page,requests.length,criteria):responses[requests.length-1]);
  if(value instanceof Error)throw value;
  if(value?.error!==undefined||value?.success===false)return value;
  return {success:true,data:value?.malformed?{}:{items:value??[]}};
 }};
 const get=id=>{if(cache[id])return cache[id];if(stubs[id])return stubs[id];if(real.has(id)){const e={exports:{}};cache[id]=e.exports;modules[id](e,e.exports,get);return e.exports}return {}};
 const filters={};
 if(options.productionLoop){
  settings.commonSetting={autoClearLog:false};
  stubs[82125]={getRandomNumberInRange:(a,b)=>a};
  stubs[22869].baseSettings=['buySetting','sellSetting','searchSetting'];stubs[22869].sharedSettings=[];
  stubs[36639]={clearLogs:async(e,next)=>next(e)};
  stubs[81721]={applyBaseFixes(){}};
  stubs[26774]={};
  const Store=moduleExports(modules,78017,{22869:{},89138:()=>{},33386:{},84582:{LocalDb:{instance:{}}}}).InMemoryStore;
  const instance=Object.create(Store.prototype);instance.entries=store;instance.isInitialized=true;
  stubs[32024].InMemoryStore.instance=instance;
  stubs[32024].TraderDb={instance:{get:async name=>{loads.push(name);return filters[name]?structuredClone(filters[name]):undefined}}};
  stubs[39021]={StatsFactory:{instance:{getProcessor:()=>p.statsProcessor}}};
 }
 if(options.nativeAdapter){
  const respond=stubs[13808].searchTransferMarket;
  const observable=moduleExports(modules,83195).observableToPromise;stubs[27988].observableToPromise=observable;
  stubs[74350]={sendPinEvents(){}};stubs[75212]={};
  real.add(33147);
  services.Item.searchTransferMarket=(criteria,page)=>{
   const obs={unobserve(){},observe(owner,callback){respond(criteria,page).then(result=>callback(obs,{success:result.success,data:result.data,error:result.error==null?undefined:{code:result.error}}));return obs}};return obs;
  };
  stubs[13808]=get(33147);
 }
 const orchestrator={searchMarket:get(65757).searchMarketBG,handleTransferResults:async(items)=>{eligible.push(...items);return[]},handleWonItems:async()=>{},handleTransferList:async()=>{},handleWatchList:async()=>{}};
 stubs[98003]={TransferFactory:{instance:{getTransferOrchestrator:()=>orchestrator}}};
 if(!options.productionLoop)stubs[47751]={runAutoActionsMiddlewares:async()=>{}};
 const e={exports:{}};cache[61400]=e.exports;modules[61400](e,e.exports,get);
 const p=Object.create(e.exports.TraderProcessor.prototype);e.exports.TraderProcessor._instance=p;
 Object.assign(p,{isStarted:true,traderSettings:settings,traderData:data,controllerInstance:{toggleElementsState(){},viewmodel:{searchCriteria:{type:'player',rarities:[123],defId:[],minBuy:0,minBid:0,maxBuy:400000}}},statsProcessor:{updateTempStat(){},getTempStats:()=>({tlWlCheckCycle:10000})},checkBotState:async()=>false,listCheckCount:0});
 // Keep real stop(), stubbing only UI/timer notification prerequisites.
 p.statsProcessor.stop=()=>{};p.enhancerData={};p.notifier={notifyAll(){}};
 if(options.productionLoop){
  for(const name of data.cache.filter.selectedFilters){filters[name.toUpperCase()]={criteria:structuredClone(p.controllerInstance.viewmodel.searchCriteria),baseSetting:structuredClone({buySetting:settings.buySetting,sellSetting:{},searchSetting:settings.searchSetting})};}
  settings.sellSetting={};
 }
 const cycle=()=>p.runActions(10);
 const run=async count=>{for(let i=0;i<count&&p.isStarted;i++)await cycle()};
 return{p,cycle,run,logs,requests,eligible,settings,data,get,services,store,item,context,modules,loads,filters,requestObjects};
}
test('page 1 is validated first, inclusive seconds reach only candidate handler',async()=>{
 const h=harness(()=>[item(1,3539),item(2,3540),item(3,3600),item(4,3601)]);await h.cycle();
 assert.equal(h.requests[0].page,1);assert.deepEqual(h.eligible.map(i=>i.id),[2,3]);assert.match(h.logs.at(-1),/confirmed=unknown.*offset=unknown.*target=2/);
});
test('configured page 30 cannot trigger an unsupported direct jump',async()=>{
 let previous=0;const h=harness(page=>{assert.ok(page<=previous+1);previous=page;return[item(page,page===30?3550:40)]},{search:{startingSearchPage:30}});await h.run(30);
 assert.equal(h.requests.length,30);assert.deepEqual(h.requests.map(r=>r.page),Array.from({length:30},(_,i)=>i+1));assert.equal(h.eligible[0].id,30);
});
test('starting beyond final page recovers by sequential initialization and terminates at empty edge',async()=>{
 const h=harness(page=>page<3?[item(page,20)]:[],{search:{startingSearchPage:99}});await h.run(20);
 assert.deepEqual(h.requests.map(r=>r.page),[1,2,3,3,3]);assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/end-or-navigation-unavailable/);
});
test('server always returning first page is detected without endless scan',async()=>{
 const h=harness(()=>[item(1,10)]);await h.run(50);assert.equal(h.requests.length,2);assert.match(h.logs.join('\n'),/repeated-listings-across-pages/);assert.equal(h.eligible.length,0);
});
test('all-empty page 30/31 regression terminates after three page-1 requests',async()=>{
 for(const start of [30,31]){const h=harness(()=>[],{search:{startingSearchPage:start}});await h.run(100);assert.deepEqual(h.requests.map(r=>r.page),[1,1,1]);assert.equal(h.p.isStarted,false)}
});
test('HTTP 429, auth, malformed and network failures are not successful empty pages',async()=>{
 for(const response of [{success:false,error:429},{success:false,error:401},{success:false,error:403},{success:false,error:500},{malformed:true},Error('network')]){
  const h=harness(()=>response);await h.run(5);assert.equal(h.requests.length,1);assert.equal(h.p.isStarted,false);assert.equal(h.eligible.length,0);assert.match(h.logs.join('\n'),/count=unknown/);
 }
});
test('random minima freeze only for fresh requests; intended filters and buy limits remain',async()=>{
 const h=harness(p=>[item(p,p<4?10:3550)]);await h.run(4);
 assert.deepEqual(h.requests.map(r=>r.criteria.minBuy),[0,0,0,0]);assert.ok(h.requests.every(r=>r.criteria.maxBuy===400000&&r.criteria.rarities[0]===123));
 const data={minBuy:0};await h.get(85462).randomizeMinBidMinBuy({data},async()=>({response:true}));assert.equal(data.minBuy,150);
});
test('criteria change starts a separate page-1 session without stale anchor',async()=>{
 const h=harness(p=>[item(p,3550)]);await h.cycle();h.p.controllerInstance.viewmodel.searchCriteria.rarities=[456];await h.cycle();assert.deepEqual(h.requests.map(r=>r.page),[1,1]);assert.ok(h.logs.filter(l=>l.includes('mode=INITIALIZING')).length===2);
});
test('target split across boundary visits both pages and both neighbours',async()=>{
 const h=harness(p=>[item(p,p===2||p===3?3550:20)]);await h.run(10);assert.ok(h.requests.some(r=>r.page===1));assert.ok(h.eligible.some(i=>i.id===2));assert.ok(h.eligible.some(i=>i.id===3));assert.ok(h.requests.some(r=>r.page===4));
});
test('moving target outside the neighbourhood triggers rediscovery',async()=>{
 const h=harness((p,count)=>[item(p,count<=3?(p===2?3550:20):(p===5?3550:20))]);await h.run(22);assert.ok(h.eligible.some(i=>i.id===2));assert.ok(h.eligible.some(i=>i.id===5));assert.match(h.logs.join('\n'),/window-moved-rescan/);
});
test('stale remembered anchor is never loaded',async()=>{
 const h=harness(()=>[item(1,3550)]);await h.cycle();assert.equal(h.requests[0].page,1);
});
test('cache/page inconsistencies with same listing set stop safely',async()=>{
 const h=harness(p=>p===1?[item(1,1),item(2,2)]:[item(2,1),item(1,2)]);await h.run(10);assert.equal(h.requests.length,2);assert.match(h.logs.join('\n'),/repeated-listings-across-pages/);
});
test('unsorted durations do not cause bisection or miss target candidates',async()=>{
 const h=harness(p=>[item(p+'a',4000),item(p+'b',20),item(p+'c',3550)]);await h.cycle();assert.equal(h.eligible.length,1);assert.equal(h.eligible[0].id,'1c');
});
test('Search Result Threshold 0, equal, exceeded preserve raw-result safeguard',async()=>{
 for(const [threshold,expected]of [[0,2],[2,2],[1,0]]){const h=harness(()=>[item(1,3550),item(2,3550)],{buy:{searchResultThreshold:threshold}});await h.cycle();assert.equal(h.eligible.length,expected);if(!expected)assert.match(h.logs.join('\n'),/post-search-blocked/)}
});
test('stop/restart clears navigation and ignores late responses',async()=>{
 const h=harness(p=>[item(p,20)]);await h.cycle();h.p.stop();assert.equal(h.p.__fcFreshNavigation,null);h.p.isStarted=true;await h.cycle();assert.deepEqual(h.requests.map(r=>r.page),[1,1]);
 const late=harness(()=>{late.p.stop();return[item(1,3550)]});await late.cycle();assert.equal(late.eligible.length,0);assert.match(late.logs.join('\n'),/minSec=3550 maxSec=3550 target=1 eligible=0/);
});
test('milliseconds, timestamps, nonnumbers, invalid seconds cannot become target',async()=>{
 for(const value of [3540000,Date.now(),'3540',NaN,null,-1,Infinity]){const h=harness(()=>[item(1,value)]);await h.cycle();assert.equal(h.eligible.length,0)}
});
test('TEST service interlock blocks native bidding and scoped search bypasses enhancer sorter/autobuy',async()=>{
 const h=harness(()=>[]);let searches=0,bids=0;h.services.Item.bid=()=>{bids++};h.services.Item.searchTransferMarket=()=>{searches++;return{}};
 h.get(30501).transferSearchOverride();assert.throws(()=>h.services.Item.bid(),/buying and bidding disabled/);assert.equal(bids,0);
 const fresh=h.get(99007);const orchestrator={searchMarket:async criteria=>{h.services.Item.searchTransferMarket(criteria,1);fresh.record(criteria,{kind:'success'});return[]}};
 await fresh.run(h.p,h.p.controllerInstance.viewmodel.searchCriteria,orchestrator,()=>{});assert.equal(searches,1);
});
test('service-side criteria mutation fails closed with normal-log diagnostics',async()=>{
 const h=harness((p,c,criteria)=>{criteria.minBuy=250;return[item(1,3550)]});await h.cycle();assert.equal(h.eligible.length,0);assert.match(h.logs.join('\n'),/search-filter-mutated:minBuy/);
});
test('configured page limit bounds discovery independently of item count',async()=>{
 const h=harness(p=>[item(p,1)],{search:{searchResultPageLimit:3}});await h.run(50);assert.equal(h.requests.length,3);assert.match(h.logs.join('\n'),/discovery-page-budget-exhausted/);
});
test('individual-player random rotation rejected in broad-market fresh mode',async()=>{
 const h=harness(()=>[item(1,3550)],{search:{filterRating:90}});await h.cycle();assert.equal(h.requests.length,0);assert.match(h.logs.join('\n'),/individual-player-rating-rotation-incompatible/);
});
test('passive fetch diagnostics log only numeric observed pagination; no tokens or guessed page',async()=>{
 const h=harness(()=>{h.context.fetch('https://example.invalid/transfermarket?start=42&num=21&sid=DO_NOT_LOG');return[item(1,3550)]},{globals:{fetch:async()=>({status:200})}});
 await h.cycle();const log=h.logs.at(-1);assert.match(log,/confirmed=unknown.*offset=42 wire=start:42,num:21 transport=fetch http=200/);assert.ok(!log.includes('DO_NOT_LOG'));assert.ok(!log.includes('example.invalid'));
});
test('multiple observed requests remain ambiguous instead of confirming a page',async()=>{
 const h=harness(()=>{h.context.fetch('https://example.invalid/transfermarket?start=0');h.context.fetch('https://example.invalid/transfermarket?start=42');return[item(1,3550)]},{globals:{fetch:async()=>({status:200})}});await h.cycle();assert.match(h.logs.at(-1),/offset=unknown wire=unknown transport=ambiguous/);
});
test('passive XHR diagnostics preserve open/send and record real observed parameters',async()=>{
 class XHR{open(method,url){this.url=url}addEventListener(type,callback){this.callback=callback}send(){this.status=200;this.callback?.()}}
 const h=harness(()=>{const xhr=new h.context.XMLHttpRequest();xhr.open('GET','https://example.invalid/transfermarket?start=21&num=21&token=PRIVATE');xhr.send();return[item(1,3550)]},{globals:{XMLHttpRequest:XHR}});await h.cycle();assert.match(h.logs.at(-1),/offset=21 wire=start:21,num:21 transport=xhr http=200/);assert.ok(!h.logs.join('\n').includes('PRIVATE'));
});
test('unchanged stale durations after 15 seconds fail closed',()=>{
 const h=harness(()=>[]);const fresh=h.get(99007),s=fresh.create('x',39);fresh.advance(s,1,[item(1,3550)],0);fresh.advance(s,1,[item(1,3550)],16000);assert.equal(s.stopped,true);assert.equal(s.reason,'stale-duration-or-cache');
});
test('known-empty neighbour is bounded and skipped while valid targets remain',async()=>{
 const h=harness(p=>p===1?[item(1,3550)]:[]);await h.run(80);assert.equal(h.p.isStarted,true);assert.match(h.logs.join('\n'),/empty-boundary-skipped-monitor-valid-target/);assert.equal(h.requests.filter(r=>r.page===2).length,6);
});
test('monitoring never requires multi-page jumps except supported page-1 reset',async()=>{
 let last=0;const h=harness(p=>{assert.ok(p===1||Math.abs(p-last)<=1,`jump ${last}->${p}`);last=p;return[item(p,p===4||p===5?3550:20)]});await h.run(35);assert.ok(h.eligible.some(i=>i.id===5));assert.ok(h.requests.some(r=>r.page===6));
});
test('existing production bid middleware rejects out-of-window cards on both initial and rebid paths',async()=>{
 const h=harness(()=>[]);let actions=0;
 const deps={32024:{InMemoryStore:{instance:{get:k=>k==='traderSettings'?{buySetting:{}}:h.data}}},27988:{getLocalization:()=>({})},9514:{runMiddlewares:async(e,chain)=>{const dispatch=async(i,e)=>i<chain.length?chain[i](e,v=>dispatch(i+1,v)):{response:true};return dispatch(0,e)}}};
 const names={91414:'addToCache',83847:'bidItem',30804:'checkBuyPrice',93727:'checkIfBasicChemistry',22850:'checkIfCached',10270:'checkIfExpired',72316:'checkIfGK',72678:'checkBidPrice',10454:'checkItemsExpires',62813:'checkIfClubPlayer',39887:'checkIfValidRatingRange'};
 for(const [id,name]of Object.entries(names))deps[id]={[name]:async(e,next)=>{if(+id===83847)actions++;return next(e)}};
 deps[53799]={};const bid=moduleExports(h.modules,7520,deps).runBidMiddlewares;
 for(const rebid of [false,true])for(const sec of [0,3539,3540,3600,3601,3540000])await bid(item(sec,sec),rebid);
 assert.equal(actions,4);
});
test('effective multi-rarity selection is preserved before fingerprint/request creation',async()=>{
 const h=harness(()=>[item(1,3550)]);h.p.controllerInstance.viewmodel.searchCriteria.rarities=[];h.store.enhancerSettings.multiRarities=new Set([123,456]);await h.cycle();assert.deepEqual(h.requests[0].criteria.rarities,[123,456]);
});
test('enhancer exclusion filter still gates candidates after raw-page navigation',async()=>{
 const h=harness(()=>[item(1,3550),item(2,3550)]);h.get(71446).filterResult=items=>items.filter(i=>i.id!==1);await h.cycle();assert.deepEqual(h.eligible.map(i=>i.id),[2]);assert.match(h.logs.at(-1),/count=2.*target=2 eligible=1/);
});
test('actual service wrapper forwards page unchanged and only clears cache at page 1',async()=>{
 const calls=[],clears=[];
 const services={Item:{clearTransferMarketCache:()=>clears.push(1),searchTransferMarket:(criteria,page)=>{calls.push([criteria,page]);return{observe(owner,callback){callback({unobserve(){}},{success:true,data:{items:[]}})}}}}};
 const {modules}=load(file,{services});
 const observable=moduleExports(modules,83195).observableToPromise;
 const api=moduleExports(modules,33147,{82125:{},26735:{},27988:{observableToPromise:observable},75212:{},74350:{sendPinEvents(){}}});
 const criteria={rarities:[123]};await api.searchTransferMarket(criteria,1);await api.searchTransferMarket(criteria,30);
 assert.equal(calls[0][0],criteria);assert.deepEqual(calls.map(c=>c[1]),[1,30]);assert.equal(clears.length,1);
});
test('prototype-level TEST interlock also blocks direct class bidding',()=>{
 function UTItemService(){}UTItemService.prototype.bid=()=>{throw Error('Native should never execute')};
 const h=harness(()=>[],{globals:{UTItemService}});h.services.Item.searchTransferMarket=()=>({});h.get(30501).transferSearchOverride();assert.throws(()=>new UTItemService().bid(),/buying and bidding disabled/);assert.match(h.logs.at(-1),/TEST interlock blocked/);
});
test('modern client filtering cannot turn a populated raw market page into an empty-page decision',async()=>{
 const h=harness((p,c,criteria)=>{h.get(99007).captureRaw(criteria,[item(p,3550)]);return[]});await h.cycle();assert.equal(h.p.isStarted,true);assert.equal(h.eligible.length,0);assert.match(h.logs.at(-1),/count=1.*source=index-pre-filter filteredCount=0 target=1 eligible=0/);
});
test('actual modern bundle hook captures original response before RXe hides listings',async()=>{
 const fs=require('node:fs'),vm=require('node:vm');
 const s=fs.readFileSync(__dirname+'/../patched/js/index.js','utf8');const start=s.indexOf('CXe=')+4,end=s.indexOf(',kXe=',start);assert.ok(start>3&&end>start);
 const h=harness(()=>[]);h.get(99007);const criteria=h.p.controllerInstance.viewmodel.searchCriteria;
 const original=[item(1,3550),item(2,20)],response={success:true,data:{items:original}};
 h.services.Item.searchTransferMarket=()=>({observe(owner,cb){cb({unobserve(){}},response)}});
 Object.assign(h.context,{Kpe(){},MXe(){},kXe(){},TXe(){},j0(){},Cx:{},OXe(){},IXe(){},RXe:items=>items.filter(i=>i.id!==1)});
 vm.runInContext('('+s.slice(start,end)+')()',h.context);
 const orchestrator={searchMarket:async request=>{h.services.Item.searchTransferMarket(request,1);const fresh=h.get(99007);fresh.setEligible(request,response.data.items);fresh.record(request,{kind:'success'});return fresh.raw(request,response.data.items)}};
 const outcome=await h.get(99007).run(h.p,criteria,orchestrator,log=>h.logs.push(log));assert.equal(outcome.items.length,0);assert.match(h.logs.at(-1),/count=2.*source=index-pre-filter filteredCount=1 target=1 eligible=0/);
});
// Exact observed time ranges. The added DTO transport mutation is a modeled cause,
// not a claim that the screenshot exposes the mutated field names.
const liveItems=(page,min,max)=>Array.from({length:21},(_,i)=>item(page+'-'+i,min+i%(max-min+1)));
test('previous v7 reproduces live page 1/2 times then false-positive DTO mutation stop',async()=>{
 const h=harness((p,c,criteria)=>{criteria.offset=(p-1)*20;criteria.count=21;return p===1?liveItems(p,15,22):liveItems(p,49,57)}, {bundle:__dirname+'/../previous/js/main.js',search:{startingSearchPage:50}});
 Object.assign(h.p.controllerInstance.viewmodel.searchCriteria,{offset:0,count:21});await h.run(6);
 assert.deepEqual(h.requests.map(r=>r.page),[1,2]);assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/minSec=15 maxSec=22/);assert.match(h.logs.join('\n'),/minSec=49 maxSec=57/);assert.match(h.logs.join('\n'),/criteria-mutated-during-request/);assert.equal(h.eligible.length,0);
});
test('live sequence continues to supported starting page 50 and finds 3540-3600 seconds',async()=>{
 const h=harness((p,c,criteria)=>{
  criteria.offset=(p-1)*20;criteria.count=21;
  h.context.fetch('https://example.invalid/transfermarket?start='+criteria.offset+'&num=21');
  return p===1?liveItems(p,15,22):p===2?liveItems(p,49,57):p===50?liveItems(p,3400,3420):liveItems(p,3540,3560);
 },{search:{startingSearchPage:50,searchResultPageLimit:39},globals:{fetch:async()=>({status:200})}});
 Object.assign(h.p.controllerInstance.viewmodel.searchCriteria,{offset:0,count:21});await h.run(4);
 assert.deepEqual(h.requests.map(r=>r.page),[1,2,50,51]);assert.equal(h.p.isStarted,true);
 assert.match(h.logs.join('\n'),/requested=50.*offset=980.*target=0.*next=51/);
 assert.match(h.logs.join('\n'),/requested=51.*minSec=3540 maxSec=3560.*target=21.*mode=TARGET_FOUND/);
 assert.match(h.logs.join('\n'),/ignoredTransport=offset/);assert.ok(h.eligible.every(i=>i.getAuctionData().expires>=3540));assert.equal(h.eligible.length,21);
});
test('valid supported direct page 50 is monitored instead of returning to page 1',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');return liveItems(p,p===50?3540:30,p===50?3560:50)},{search:{startingSearchPage:50},globals:{fetch:async()=>({status:200})}});
 await h.run(4);assert.deepEqual(h.requests.map(r=>r.page),[1,2,50,50]);assert.match(h.logs.join('\n'),/access=direct-probe-validated/);assert.match(h.logs.at(-1),/mode=MONITORING/);
});
test('empty unsupported jump falls back to sequential warmup then reaches 50 despite budget 39',async()=>{
 let serverPage=0;
 const h=harness(p=>{
  h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');
  if(p!==1&&p>serverPage+1)return[];
  serverPage=p;return liveItems(p,p===50?3540:20,p===50?3560:40);
 },{search:{startingSearchPage:50,searchResultPageLimit:39},globals:{fetch:async()=>({status:200})}});
 await h.run(53);assert.deepEqual(h.requests.slice(0,5).map(r=>r.page),[1,2,50,1,2]);assert.equal(h.requests.at(-1).page,50);assert.equal(h.p.isStarted,true);assert.ok(h.eligible.length);assert.match(h.logs.join('\n'),/direct-probe-empty-or-end-fallback/);
});
test('jump replaying first-page data is rejected and sequential fallback still finds target',async()=>{
 let jumped=false;
 const h=harness(p=>{
  h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');
  if(p===50&&!jumped){jumped=true;return liveItems(1,15,22)}
  return liveItems(p,p===4?3540:15,p===4?3560:22);
 },{search:{startingSearchPage:50},globals:{fetch:async()=>({status:200})}});
 await h.run(7);assert.deepEqual(h.requests.map(r=>r.page),[1,2,50,1,2,3,4]);assert.ok(h.eligible.length);assert.match(h.logs.join('\n'),/direct-probe-replayed-baseline-fallback/);
});
test('different data at wrong observed jump offset is not trusted as requested page 50',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+(p===50?0:(p-1)*20)+'&num=21');return liveItems(p,p===50?3540:15,p===50?3560:22)},{search:{startingSearchPage:50},globals:{fetch:async()=>({status:200})}});
 await h.run(3);assert.match(h.logs.at(-1),/direct-probe-offset-unverified-fallback/);assert.equal(h.p.__fcFreshNavigation.page,1);assert.equal(h.eligible.length,0);
});
test('without observable offsets, sequential fallback reaches starting page without guessed jumps',async()=>{
 const h=harness(p=>liveItems(p,p===50?3540:15,p===50?3560:22),{search:{startingSearchPage:50,searchResultPageLimit:39}});await h.run(50);assert.deepEqual(h.requests.map(r=>r.page),Array.from({length:50},(_,i)=>i+1));assert.ok(h.eligible.length);assert.match(h.logs.join('\n'),/sequential-warmup-to-start/);
});
test('59 and 60 seconds never count as discovery and never reach purchase evaluation',async()=>{
 const h=harness(p=>[item(p+'a',59),item(p+'b',60)]);await h.run(4);assert.deepEqual(h.requests.map(r=>r.page),[1,2,3,4]);assert.equal(h.eligible.length,0);assert.ok(h.logs.filter(l=>l.includes('[Fresh] requested=')).every(l=>l.includes('target=0')&&!l.includes('mode=TARGET_FOUND')));
});
test('semantic filter changes still stop, but all known DTO pagination mutations continue',async()=>{
 const h=harness((p,c,criteria)=>{Object.assign(criteria,{offset:20,count:21,start:20,num:21,page:p,pageIndex:p-1,_offset:20});return liveItems(p,49,57)});await h.run(3);assert.equal(h.p.isStarted,true);assert.deepEqual(h.requests.map(r=>r.page),[1,2,3]);assert.match(h.logs.at(-1),/ignoredTransport=/);
 const bad=harness((p,c,criteria)=>{criteria.rarities=[999];return liveItems(p,3540,3560)});await bad.cycle();assert.equal(bad.p.isStarted,false);assert.match(bad.logs.join('\n'),/search-filter-mutated:rarities/);assert.equal(bad.eligible.length,0);
});
test('calibrated 20-stride is learned, never computed from count 21',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*7)+'&num=13');return liveItems(p,15,22)},{search:{startingSearchPage:50},globals:{fetch:async()=>({status:200})}});await h.run(3);assert.match(h.logs.at(-1),/offset=343/);assert.match(h.logs.at(-1),/access=direct-probe-validated/);
});
test('above-window starting page probes backwards and finds an earlier fresh band',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');return p<3?liveItems(p,15,22):p===49?liveItems(p,3540,3560):liveItems(p,3700,3720)},{search:{startingSearchPage:50},globals:{fetch:async()=>({status:200})}});await h.run(4);assert.deepEqual(h.requests.map(r=>r.page),[1,2,50,49]);assert.ok(h.eligible.length);assert.match(h.logs.join('\n'),/above-target-probe-earlier/);
});
test('page budget 39 at validated starting page 50 permits page 88 then stops explicitly',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');return liveItems(p,200,220)},{search:{startingSearchPage:50,searchResultPageLimit:39},globals:{fetch:async()=>({status:200})}});await h.run(60);assert.equal(h.requests.length,41);assert.equal(h.requests.at(-1).page,88);assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/discovery-page-budget-exhausted/);
});
test('rate limit at direct probe stops immediately, never attempts a sequential bypass',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');return p===50?{success:false,error:429}:liveItems(p,15,22)},{search:{startingSearchPage:50},globals:{fetch:async()=>({status:200})}});await h.run(10);assert.deepEqual(h.requests.map(r=>r.page),[1,2,50]);assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/status=429/);
});
test('starting page 2 is already sequentially validated and is not redundantly jump-probed',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');return liveItems(p,15,22)},{search:{startingSearchPage:2},globals:{fetch:async()=>({status:200})}});await h.run(3);assert.deepEqual(h.requests.map(r=>r.page),[1,2,3]);assert.match(h.logs.join('\n'),/configured-start-already-validated-sequentially/);
});
test('changing observed page size makes a direct-jump calibration ineligible',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num='+(p===1?21:41));return liveItems(p,15,22)},{search:{startingSearchPage:50},globals:{fetch:async()=>({status:200})}});await h.run(3);assert.deepEqual(h.requests.map(r=>r.page),[1,2,3]);assert.match(h.logs.join('\n'),/no-observable-offset-calibration/);
});
const previous71=__dirname+'/../baseline-v71/js/main.js';
function recoveryFixture(options={}){
 let serverPage=0;
 const h=harness((page,count,criteria)=>{
  h.context.fetch('https://example.invalid/transfermarket?start='+((page-1)*20)+'&num=21');
  criteria.offset=(page-1)*20;criteria.count=21;
  if(page!==1&&page>serverPage+1)return[];
  serverPage=page;
  return liveItems(page,page===20?3540:page===1?44:41,page===20?3560:page===1?51:50);
 },{productionLoop:true,nativeAdapter:true,search:{startingSearchPage:20,searchResultPageLimit:39,useRandomMinBuy:false,useRandomMinBid:false},filter:{currentFilter:'SCREAM',selectedFilters:['SCREAM'],noOfTimesRange:[4,4]},globals:{fetch:async()=>({status:200})},...options});return h;
}
test('v7.1 exact 1,2,20,1 recovery persists through actual single-SCREAM reload and native adapter',async()=>{
 const h=recoveryFixture({bundle:previous71});await h.run(9);assert.deepEqual(h.requests.map(r=>r.page),[1,2,20,1,2,3,4,5,6]);assert.equal(h.p.isStarted,true);assert.ok(h.loads.filter(n=>n==='SCREAM').length>=1);assert.equal(h.requests.filter(r=>r.page===20).length,1);assert.match(h.logs.join('\n'),/direct-probe-empty-or-end-fallback/);
});
test('v7.1 actual multi-filter rotation can repeatedly restart calibration without discovery',async()=>{
 const h=recoveryFixture({bundle:previous71,filter:{currentFilter:'SCREAM',selectedFilters:['SCREAM','OTHER'],noOfTimesRange:[1,1]}});await h.run(8);assert.deepEqual(h.requests.map(r=>r.page),Array(8).fill(1));assert.ok(h.loads.includes('SCREAM')&&h.loads.includes('OTHER'));assert.equal(h.eligible.length,0);
});
test('v7.1 concurrent real runActions can dispatch duplicate page-1 requests before locking',async()=>{
 const h=recoveryFixture({bundle:previous71});await Promise.all([h.cycle(),h.cycle()]);assert.deepEqual(h.requests.map(r=>r.page),[1,1]);
});
test('v7.2 exact failed page-20 probe uses actual loop/adapter then reaches page 3 without reprobing',async()=>{
 const h=recoveryFixture();await h.run(9);assert.deepEqual(h.requests.map(r=>r.page),[1,2,20,1,2,3,4,5,6]);assert.equal(h.requests.filter(r=>r.page===20).length,1);assert.equal(h.p.__fcFreshNavigation.directProbeFailed,true);assert.equal(h.p.__fcFreshNavigation.warmup,true);assert.equal(h.loads.filter(n=>n==='SCREAM').length,0);assert.match(h.logs.join('\n'),/state=SEQUENTIAL_WARMUP.*nextRequested=3/);
});
test('v7.2 actual sequential fallback reaches 3559s target on page 20 and monitors it',async()=>{
 const h=recoveryFixture();await h.run(24);assert.deepEqual(h.requests.slice(0,7).map(r=>r.page),[1,2,20,1,2,3,4]);assert.equal(h.requests[22].page,20);assert.ok(h.eligible.some(i=>i.getAuctionData().expires===3559));assert.equal(h.p.isStarted,true);assert.match(h.logs.join('\n'),/comparison=direct-empty-sequential-populated-time-varying-evidence/);assert.match(h.logs.join('\n'),/mode=MONITORING/);
});
test('same SCREAM assignments, fresh criteria objects and deleted processor pointers do not restart recovery',async()=>{
 const h=recoveryFixture();await h.run(4);const expected=[2,3,4,5];
 for(const page of expected){h.p.__fcFreshNavigation=null;h.data.cache.filter.currentFilter='SCREAM';h.p.controllerInstance.viewmodel.searchCriteria=structuredClone(h.p.controllerInstance.viewmodel.searchCriteria);await h.cycle();assert.equal(h.requests.at(-1).page,page)}
 assert.equal(h.requests.filter(r=>r.page===20).length,1);assert.match(h.logs.join('\n'),/resetReason=processor-pointer-restored/);assert.equal(h.p.__fcFreshNavigation.directProbeFailed,true);
});
test('processor recreation sharing real Trader data restores sequential warmup instead of calibration',async()=>{
 const h=recoveryFixture();await h.run(4);
 const replacement=Object.assign(Object.create(Object.getPrototypeOf(h.p)),h.p,{__fcFreshNavigation:null,isOperationInProgress:false});
 await replacement.runActions(10);assert.equal(h.requests.at(-1).page,2);await replacement.runActions(10);assert.equal(h.requests.at(-1).page,3);assert.equal(replacement.__fcFreshNavigation.directProbeFailed,true);
});
test('same-market controller rebinding preserves recovery and emits its lifecycle cause',async()=>{
 const h=recoveryFixture();await h.run(4);h.p.setControllerInstance({toggleElementsState(){},viewmodel:{searchCriteria:structuredClone(h.p.controllerInstance.viewmodel.searchCriteria)}});await h.cycle();assert.equal(h.requests.at(-1).page,2);assert.match(h.logs.join('\n'),/resetReason=controller-rebound-context-preserved resetSource=TraderProcessor.setControllerInstance/);
});
test('failed-probe latch prevents forced re-entry into calibration/probe during recovery',async()=>{
 const h=recoveryFixture();await h.run(4);h.p.__fcFreshNavigation.accessStage='PROBE_START';h.p.__fcFreshNavigation.page=20;await h.cycle();assert.equal(h.requests.at(-1).page,1);assert.equal(h.requests.filter(r=>r.page===20).length,1);assert.match(h.logs.join('\n'),/failed-probe-latch-prevented-recalibration/);
});
test('actual multi-filter rotation is deferred during bounded discovery and cannot restart every request',async()=>{
 const h=recoveryFixture({filter:{currentFilter:'SCREAM',selectedFilters:['SCREAM','OTHER'],noOfTimesRange:[1,1]}});await h.run(9);assert.deepEqual(h.requests.map(r=>r.page),[1,2,20,1,2,3,4,5,6]);assert.ok(!h.loads.includes('OTHER'));assert.match(h.logs.join('\n'),/rotation-deferred-during-discovery/);
});
test('saved same-SCREAM settings cannot silently replace active start/page budget during fallback',async()=>{
 const h=recoveryFixture();h.filters.SCREAM.baseSetting.searchSetting.startingSearchPage=99;h.filters.SCREAM.baseSetting.searchSetting.searchResultPageLimit=1;await h.run(8);assert.deepEqual(h.requests.map(r=>r.page),[1,2,20,1,2,3,4,5]);assert.equal(h.settings.searchSetting.startingSearchPage,20);assert.equal(h.settings.searchSetting.searchResultPageLimit,39);assert.equal(h.loads.length,0);
});
test('unchanged semantic criteria retain the same fingerprint across transport changes/reapplied SCREAM',async()=>{
 const h=recoveryFixture();await h.run(9);const lines=h.logs.filter(line=>line.includes('[Fresh] requested='));const keys=lines.map(line=>line.match(/criteria=([a-f0-9]+)/)[1]);assert.equal(new Set(keys).size,1);assert.ok(lines.every(line=>line.includes('previousState=')&&line.includes('nextState=')&&line.includes('directProbeFailed=')&&line.includes('observedCount=')));
});
test('genuine changed search context resets with a cause and repeated context flipping stops by watchdog',async()=>{
 const h=recoveryFixture({filter:{currentFilter:'SCREAM',selectedFilters:[]}});
 for(let i=0;i<20&&h.p.isStarted;i++){h.data.cache.filter.currentFilter=i%2?'OTHER':'SCREAM';h.p.controllerInstance.viewmodel.searchCriteria.rarities=i%2?[456]:[123];await h.cycle()}
 assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/search-context-changed/);assert.match(h.logs.join('\n'),/discovery-progress-watchdog/);assert.ok(h.requests.length<=14);
});
test('cyclic warmup 1/2 requests with no new valid page trips watchdog instead of hanging',async()=>{
 const h=recoveryFixture();await h.run(4);
 for(let i=0;i<20&&h.p.isStarted;i++){const s=h.p.__fcFreshNavigation;s.page=i%2?2:1;await h.cycle()}
 assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/discovery-progress-watchdog:no-new-valid-page-in-12-requests/);
});
test('legitimate monitoring refreshes are exempt from discovery watchdog',async()=>{
 const h=harness(()=>liveItems(1,3540,3560),{search:{startingSearchPage:1},productionLoop:true,nativeAdapter:true});
 h.get(99007).advance;await h.cycle();
 // Refresh a single confirmed-by-content target page; other watchdog cases cover bad discovery.
 for(let i=0;i<20;i++){h.p.__fcFreshNavigation.page=1;await h.cycle()}
 assert.equal(h.p.isStarted,true);assert.match(h.logs.at(-1),/progress=monitoring-refresh/);
});
test('concurrent actual runActions is locked before pre-search await and sends only one request',async()=>{
 const h=recoveryFixture();await Promise.all([h.cycle(),h.cycle(),h.cycle()]);assert.deepEqual(h.requests.map(r=>r.page),[1]);assert.equal(h.p.isOperationInProgress,false);
});
test('stop during actual asynchronous filter loading prevents a late native market request',async()=>{
 const h=recoveryFixture({filter:{currentFilter:'SCREAM',selectedFilters:['OTHER'],currentFilterRunCount:1,noOfTimesToRun:1}});
 const db=h.get(32024).TraderDb.instance;db.get=async name=>{h.p.stop();return h.filters[name]};await h.cycle();assert.equal(h.requests.length,0);assert.equal(h.p.isStarted,false);assert.equal(h.p.isOperationInProgress,false);
});
test('missing controller criteria releases early lock and allows a later healthy cycle',async()=>{
 const h=recoveryFixture();const criteria=h.p.controllerInstance.viewmodel.searchCriteria;h.p.controllerInstance.viewmodel.searchCriteria=null;await h.cycle();assert.equal(h.p.isOperationInProgress,false);h.p.controllerInstance.viewmodel.searchCriteria=criteria;await h.cycle();assert.equal(h.requests.length,1);
});
test('wrong observed sequential offset at page 3 stops; internal counter cannot fake advancement',async()=>{
 let serverPage=0;const h=harness(p=>{
 h.context.fetch('https://example.invalid/transfermarket?start='+(p===3?20:(p-1)*20)+'&num=21');
 if(p!==1&&p>serverPage+1)return[];serverPage=p;return liveItems(p,41,50);
 },{search:{startingSearchPage:20},productionLoop:true,nativeAdapter:true,globals:{fetch:async()=>({status:200})}});
 await h.run(10);assert.deepEqual(h.requests.map(r=>r.page),[1,2,20,1,2,3]);assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/observed-sequential-request-offset-mismatch/);
});
test('sequential page-3 successful empty tail is finite and explicitly inconclusive',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');return p<3?liveItems(p,p===1?44:41,p===1?51:50):[]},{search:{startingSearchPage:20},productionLoop:true,nativeAdapter:true,globals:{fetch:async()=>({status:200})}});await h.run(20);assert.deepEqual(h.requests.map(r=>r.page),[1,2,20,1,2,3,3,3]);assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/emptyClass=successful-empty-inconclusive/);assert.match(h.logs.join('\n'),/end-or-navigation-unavailable/);
});
test('HTTP 429 at page 20 through the actual request adapter stops with no fallback bypass',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');return p===20?{success:false,error:429}:liveItems(p,41,50)},{search:{startingSearchPage:20},productionLoop:true,nativeAdapter:true,globals:{fetch:async()=>({status:200})}});await h.run(10);assert.deepEqual(h.requests.map(r=>r.page),[1,2,20]);assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/status=429/);
});
test('non-Auto-Find retains original scheduled filter load behavior',async()=>{
 const h=recoveryFixture({search:{autoFindNewest:false,startingSearchPage:1,searchResultPageLimit:3},filter:{currentFilter:'SCREAM',selectedFilters:['SCREAM'],noOfTimesRange:[1,1]}});await h.run(3);assert.ok(h.loads.includes('SCREAM'));
});
test('two processor owners sharing Trader data cannot overlap native market requests',async()=>{
 let release;const gate=new Promise(resolve=>{release=resolve});let entered;const reached=new Promise(resolve=>{entered=resolve});
 const h=harness(async p=>{entered();await gate;return liveItems(p,41,50)},{productionLoop:true,nativeAdapter:true});
 const first=h.cycle();await reached;
 const second=Object.assign(Object.create(Object.getPrototypeOf(h.p)),h.p,{isOperationInProgress:false,__fcFreshNavigation:null});await second.runActions(10);release();await first;
 assert.equal(h.requests.length,1);assert.match(h.logs.join('\n'),/shared-session-request-deferred/);
});
test('real controller filter change while awaiting a native response discards stale candidates safely',async()=>{
 const h=harness((p,c,request)=>{h.p.controllerInstance.viewmodel.searchCriteria.rarities=[999];return liveItems(p,3540,3560)},{productionLoop:true,nativeAdapter:true});await h.cycle();assert.equal(h.eligible.length,0);assert.equal(h.p.isStarted,false);assert.match(h.logs.join('\n'),/search-context-changed-while-awaiting-response/);
});
test('adjacent 21-result pages can overlap by one listing without triggering a false replay',async()=>{
 const h=harness(p=>{h.context.fetch('https://example.invalid/transfermarket?start='+((p-1)*20)+'&num=21');return Array.from({length:21},(_,i)=>item((p-1)*20+i,41+i%10))},{search:{startingSearchPage:20},productionLoop:true,nativeAdapter:true,globals:{fetch:async()=>({status:200})}});await h.run(2);assert.equal(h.p.isStarted,true);assert.match(h.logs.at(-1),/overlapPrevious=1 observedCount=21/);
});
test('legitimate rotation after finding a target lets another market discover its own later pages',async()=>{
 const h=harness(p=>liveItems(p,h.data.cache.filter.currentFilter==='SCREAM'||p===20?3540:41,h.data.cache.filter.currentFilter==='SCREAM'||p===20?3560:50),{productionLoop:true,nativeAdapter:true,search:{startingSearchPage:1,searchResultPageLimit:39},filter:{currentFilter:'SCREAM',selectedFilters:['SCREAM','OTHER'],noOfTimesRange:[1,1]}});
 await h.run(21);assert.equal(h.p.isStarted,true);assert.ok(h.loads.includes('OTHER'));assert.equal(h.requests.at(-1).page,20);assert.equal(h.data.cache.filter.currentFilter,'OTHER');assert.match(h.logs.at(-1),/mode=TARGET_FOUND/);
});

module.exports={harness,recoveryFixture,liveItems,previous71};
