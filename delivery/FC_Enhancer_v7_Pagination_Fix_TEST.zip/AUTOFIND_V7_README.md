# Install and test v7 — UNVERIFIED ON LIVE EA

1. In chrome://extensions, disable the previous FC Enhancer extension. Close existing EA Web App tabs.
2. Extract FC_Enhancer_v7_Pagination_Fix_TEST.zip into a permanent folder. Do not try to load the ZIP itself.
3. Enable Chrome Developer mode, choose Load unpacked, and select the extracted folder containing manifest.json. The name should say “v7 Pagination TEST (NO BUYING)”.
4. Open a new Web App tab. This build blocks Item-service purchases AND bids throughout the tab, including manual purchases. Do not use it for normal trading. Restoring the old extension requires disabling v7 and reloading the Web App.
5. In Trader, select the broad Ultimate Scream player rarity filter, with no named player. Keep rating range 10–99, your intended maximum buy-price and all normal safety settings. Individual-player Filter Rating rotation must be off. Do not enable other auto-buy features. Use normal search delays and stop/pause settings.
6. Enable Auto-Find; retain Search Page Limit 39. Starting Search Page 30 may remain: v7 intentionally validates sequentially from 1 rather than trusting the hint. In normal log settings select ALL (or INFO), and inspect the [Fresh] lines.

What to look for (illustrative values, not live observations):

- Startup: `mode=INITIALIZING ... reason=sequential-validation-from-1 buying=DISABLED`.
- Request progression: requested/servicePage should advance 1,2,3...; a stable criteria fingerprint should remain unchanged. When visible, `wire=start:...,num:...` or the actual observed page fields should advance consistently. No offset formula or 21-item page size is assumed.
- Valid responses: numeric `count`, minSec and maxSec; `status=success`. Source `index-pre-filter` means captured before modern hidden-item filtering; compare filteredCount. A positive raw count with filteredCount=0 is a client exclusion result, not an empty raw page.
- Target located: `target` greater than 0 and `mode=TARGET_FOUND`, with seconds within the inclusive 3540–3600 window. `eligible` may be lower because your exclusion filters still apply.
- Monitoring: `mode=MONITORING` or `PROBING_NEIGHBOUR`, reason target-and-neighbour-monitor/probe-neighbour. Requested pages should revisit the target band and both boundaries. If the band moves away, `reason=window-moved-rescan` restarts discovery.
- No purchases/bids: `buying=DISABLED`; an attempted purchase emits `TEST interlock blocked purchase/bid` and does not invoke EA's original bid method.

**Never regard requested=30 as proof of returned page 30.** Confirmed remains unknown unless a later build gains authoritative metadata. Advancing wire parameters plus changing listings are evidence to assess, not a server-page guarantee. `transport=cache-or-unobserved`, unknown offsets or ambiguous correlation do not confirm live network advancement. If no wire evidence is available, this test cannot conclusively validate pagination from logs alone.

Stop/failure examples:

- repeated-listings-across-pages: identical complete listing identities at different requested pages; cannot trust navigation.
- successful-empty-retry: bounded retry of a successful empty array; does not imply a block.
- empty-first-page / end-or-navigation-unavailable / repeated-empty-neighbour: empty responses exhausted the bounded budget. A genuine end of list is possible.
- service-error with status=429 or observed http=429: stop and respect EA's limit. Do not immediately restart in a retry loop.
- pre-search-blocked / post-search-blocked: existing validators or result threshold stopped the request/candidates. Review the preceding normal log message; do not automatically disable safeguards.
- criteria-mutated-during-request: another layer changed search criteria; stop and investigate.
- stale-duration-or-cache: unchanged durations persisted beyond 15 seconds; cannot trust freshness.
- scope-exhausted-no-target: the configured discovery scope contains no observed target. This does not mean EA blocks pagination. Do not keep changing Starting Search Page as a workaround.

Stop manually after collecting a short sequence of [Fresh] logs. If validation fails, provide those normal-interface log lines, including initialization and the terminal reason; no F12, tokens, cookies or private session details are needed. This artifact remains UNVERIFIED ON LIVE EA until those observations exist.
