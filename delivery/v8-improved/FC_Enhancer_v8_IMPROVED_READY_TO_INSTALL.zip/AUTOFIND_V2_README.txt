FC Enhancer Auto-Find Newest v2 - experimental.
Start from page 30, back off on empty results, then walk forward from a populated page. Search responses can be empty or filtered by EA and are not proof of the final page. Only 59:00-60:00 listings reach the purchase handler.
Keep automatic buying disabled while testing. No live EA validation was possible.
Logs: [FC Fresh Pages v2] in the EA Web App page Console, not necessarily the service worker Console.
