globalThis.__fcUniversalNativeRarities=[{"id":-1,"label":"Any","value":-1},{"id":0,"label":"Common","value":0},{"id":9,"label":"Base Hall of FUT","value":9},{"id":72,"label":"Base Hero","value":72},{"id":12,"label":"Base Icon","value":12},{"id":160,"label":"Debut International Icon","value":160},{"id":22,"label":"Destined for Glory","value":22},{"id":103,"label":"FC Heritage","value":103},{"id":19,"label":"FUT Champions","value":19},{"id":71,"label":"Future Stars","value":71},{"id":150,"label":"Ones to Watch","value":150},{"id":177,"label":"POTM LIGA F","value":177},{"id":114,"label":"POTM Serie A","value":114},{"id":58,"label":"Showdown","value":58},{"id":57,"label":"Showdown Upgrade","value":57},{"id":8,"label":"Star Performer","value":8},{"id":3,"label":"Team of the Week","value":3},{"id":151,"label":"Ultimate Scream","value":151},{"id":168,"label":"Ultimate Scream Hero","value":168}];
const root='',path={join:(...parts)=>parts.join('/')};const moduleExports=(modules,id,stubs={})=>{const m={exports:{}};modules[id](m,m.exports,key=>{if(!(key in stubs))throw Error('Missing fixture dependency '+key);return stubs[key]});return m.exports};const load=(file,globals={})=>{for(const [key,value]of Object.entries(globals)){if(!['navigator','performance','setTimeout','clearTimeout','localStorage'].includes(key))globalThis[key]=value;}return{modules:globalThis.__fcProductionFactories,context:globalThis}};const file='offline-installed';const item=()=>{};const baseHarness=function harness(responses,options={}) {
 const logs=[],requests=[],eligible=[],loads=[],requestObjects=[];
 const settings={searchSetting:{autoFindNewest:true,startingSearchPage:1,searchResultPageLimit:39,useRandomMinBuy:true,randomMinBuy:300,...options.search},buySetting:{searchResultThreshold:21,...options.buy},safeSetting:{}};
 const data={cache:{filter:{currentFilter:'scream',selectedFilters:[],currentFilterRunCount:0,noOfTimesToRun:0,noOfTimesRange:[4,4],runSequentially:true,...options.filter},nextPageNumber:1,minPriceByFilter:new Map()}};
 const store={traderSettings:settings,traderData:data,enhancerSettings:{multiRarities:new Set(),searchSortField:'buy'},enhancerData:{}};
 const services={Notification:{clearAll(){}},Item:{clearTransferMarketCache(){},bid(){throw Error('Native bid must never execute')}}};
 const {modules,context}=load(options.bundle||file,{structuredClone,URL,services,...options.globals,localStorage:options.storage||{getItem(){throw Error('Stale storage must not be read')},setItem(){throw Error('must not persist anchors')}}});
 if(options.installGuard)options.installGuard(context);const stubs={32024:{InMemoryStore:{instance:{get:k=>store[k]}}},27988:{getLocalization:()=>({}),getNextStepValue:x=>x?x+50:150},22869:{ExternalNotificationType:{STOPPED:"STOPPED"}},51477:{Logger:{writeToLog:x=>{logs.push(x);globalThis.__fcRenderLog?.(x)},writeSearchResultsToLog:(items,page,criteria)=>logs.push('Found '+items.length+' page '+page+' minBuy '+criteria.minBuy)}},26735:{UINotificationTypeEnum:{NEUTRAL:1}},44669:{translate:k=>k}};
 stubs[71446]={filterResult:items=>items};
 const cache={};
 const real=new Set([99009,99011,99012,99013,99014,99015,99016,99017,99018,99019,99020,99021,99022,99023,99026,99027,99028,53799,7520,72316,93727,39887,10270,30804,22850,62813,72678,10454,91414,83847,30154,51171,2113,65734,43301,47847,37134,35123,84557,99007,85462,1098,4364,3434,65685,65757,30501]);
 if(options.productionLoop)for(const id of [875,47751,55503,17820])real.add(id);
 const noOp={buyPriceValidator:async(e,next)=>next(e),enhancerSettingValidator:async(e,next)=>next(e),getPlayersByrating:async(e,next)=>next(e),ratingValidator:async(e,next)=>next(e),updateSearchCount:async(e,next)=>next(e),increaseFilterSearchCount:async(e,next)=>next(e),setCurrentPageNumber:async(e,next)=>next(e),resetEnhancerDataRating:async(e,next)=>next(e),getRealTimePriceForResults:async(e,next)=>next(e)};
 for(const id of [58104,94697,5152,85472,33077,55503,80966,31476,7864])if(!real.has(id))stubs[id]=noOp;
 stubs[9514]={runMiddlewares:async(input,chain)=>{const dispatch=async(i,e)=>i<chain.length?chain[i](e,v=>dispatch(i+1,v)):{response:true};return dispatch(0,input)}};
 stubs[31679]={runErrorSearchMiddlewares:async()=>{}};
 stubs[13808]={searchTransferMarket:async(criteria,page)=>{
  requests.push({page,criteria:structuredClone(criteria)});requestObjects.push(criteria);
  const value=await (typeof responses==='function'?responses(page,requests.length,criteria):responses[requests.length-1]);
  if(value instanceof Error)throw value;
  if(value?.error!==undefined||value?.success===false)return value;
  return {success:true,data:value?.malformed?{}:{items:value??[]}};
 }};
 const get=id=>{if(cache[id])return cache[id];if(stubs[id])return stubs[id];if(real.has(id)){const e={exports:{}};cache[id]=e.exports;modules[id](e,e.exports,get);return e.exports}return {}};
 const filters={};
 if(options.productionLoop){
  settings.commonSetting={autoClearLog:false};
  stubs[82125]={getRandomNumberInRange:(a,b)=>a};
  stubs[22869].baseSettings=['buySetting','sellSetting','searchSetting'];stubs[22869].sharedSettings=[];
  stubs[36639]={clearLogs:async(e,next)=>next(e)};
  stubs[81721]={applyBaseFixes(){}};
  stubs[26774]={};
  const Store=moduleExports(modules,78017,{22869:{},89138:()=>{},33386:{},84582:{LocalDb:{instance:{}}}}).InMemoryStore;
  const instance=Object.create(Store.prototype);instance.entries=store;instance.isInitialized=true;
  stubs[32024].InMemoryStore.instance=instance;
  stubs[32024].TraderDb={instance:{get:async name=>{loads.push(name);return filters[name]?structuredClone(filters[name]):undefined}}};
  stubs[39021]={StatsFactory:{instance:{getProcessor:()=>p.statsProcessor}}};
 }
 if(options.transactionStubs)Object.assign(stubs,options.transactionStubs(store,services));if(options.nativeAdapter){
  const respond=stubs[13808].searchTransferMarket;
  const observable=moduleExports(modules,83195).observableToPromise;stubs[27988].observableToPromise=observable;
  stubs[74350]={sendPinEvents(){}};stubs[75212]={};
  real.add(33147);
  services.Item.searchTransferMarket=(criteria,page)=>{
   const obs={unobserve(){},observe(owner,callback){respond(criteria,page).then(result=>callback(obs,{success:result.success,data:result.data,error:result.error==null?undefined:{code:result.error}}));return obs}};return obs;
  };
  stubs[13808]=get(33147);
 }
 if(options.augmentApi)options.augmentApi(stubs[13808]);const orchestrator={searchMarket:get(65757).searchMarketBG,handleTransferResults:async(items)=>{eligible.push(...items);return[]},handleWonItems:async()=>{},handleTransferList:async()=>{},handleWatchList:async()=>{}};
 stubs[98003]={TransferFactory:{instance:{getTransferOrchestrator:()=>orchestrator}}};
 if(!options.productionLoop)stubs[47751]={runAutoActionsMiddlewares:async()=>{}};
 const e={exports:{}};cache[61400]=e.exports;modules[61400](e,e.exports,get);
 const p=Object.create(e.exports.TraderProcessor.prototype);e.exports.TraderProcessor._instance=p;
 Object.assign(p,{isStarted:true,traderSettings:settings,traderData:data,controllerInstance:{toggleElementsState(){},viewmodel:{searchCriteria:{type:'player',rarities:[123],defId:[],minBuy:0,minBid:0,maxBuy:400000}}},statsProcessor:{updateTempStat(){},getTempStats:()=>({tlWlCheckCycle:10000})},checkBotState:async()=>false,listCheckCount:0});
 // Keep real stop(), stubbing only UI/timer notification prerequisites.
 p.statsProcessor.stop=()=>{};p.enhancerData={};p.notifier={notifyAll(){}};
 if(options.productionLoop){
  for(const name of data.cache.filter.selectedFilters){filters[name.toUpperCase()]={criteria:structuredClone(p.controllerInstance.viewmodel.searchCriteria),baseSetting:structuredClone({buySetting:settings.buySetting,sellSetting:{},searchSetting:settings.searchSetting})};}
  settings.sellSetting={};
 }
 const cycle=()=>p.runActions(10);
 const run=async count=>{for(let i=0;i<count&&p.isStarted;i++)await cycle()};
 return{p,cycle,run,logs,requests,eligible,settings,data,get,services,store,item,context,modules,loads,filters,requestObjects};
};const createSession=function(scenario={}){
 const events=[],inventory=new Set(scenario.inventory||[]),journal=scenario.journal||new Map();const RealDate=Date;let virtualNow=RealDate.now();let coins=scenario.coins??5000,h,searchIndex=0,attempts=0,finished=false;
 const storage={getItem:k=>journal.get(k)??null,setItem:(k,v)=>journal.set(k,v)};
 const wait=ms=>new Promise(r=>setTimeout(r,ms));
 const make=(spec)=>{const state={owned:false,expired:false};const auction={tradeId:String(spec.id),buyNowPrice:spec.price??900,expires:spec.seconds??3559,isExpired:()=>state.expired,isWon:()=>state.owned};return{id:1000000000+Number(spec.id),definitionId:spec.player??Number(spec.id),rareflag:spec.rarity??scenario.rarity??151,type:'player',rating:85,preferredPosition:1,playStyle:1,_auction:auction,_spec:spec,_state:state,getAuctionData:()=>auction,getStaticData:()=>({name:'Player '+(spec.player??spec.id)})}};
 const pages=(scenario.pages||[]).map(items=>items.map(make));
 const observable=fn=>({unobserve(){},observe(owner,callback){Promise.resolve().then(fn).then(result=>callback(this,result));return this}});
 h=baseHarness(async(page,count,criteria)=>{if(criteria.defId?.length){const definition=criteria.defId[0];const target=pages.flat().find(x=>x.definitionId===definition);if(target?._spec.pricingError)return{success:false,error:503};if(scenario.onQuote)await scenario.onQuote({h});await wait(scenario.quoteDelayMs??1);const reference=target?._spec.profitable===false?900:(target?._spec.reference??1000);const comparables=[1,2,3,4].map((n)=>make({id:9000000+definition*10+n,player:definition,rarity:criteria.rarities[0],price:reference,seconds:3600}));events.push({kind:'price-quote',definitionId:definition,reference,at:virtualNow});return comparables;}searchIndex++;const started=performance.now();h.context.fetch('https://example.invalid/transfermarket?start='+((page-1)*20)+'&num=21');await wait(scenario.searchDelayMs??2);events.push({kind:'search',page,criteria:JSON.parse(JSON.stringify(criteria)),elapsedMs:performance.now()-started});const result=pages[searchIndex-1]||[];if(scenario.followSelectedRarity)for(const item of result)if(item._spec.rarity===undefined)item.rareflag=criteria.rarities[0];if(scenario.malformedAt===count)return{malformed:true};if(scenario.marketError&&count===scenario.marketError.at)return{success:false,error:scenario.marketError.code};return result;},{bundle:scenario.bundle||path.join(root,'.local/v8-universal-rc/js/main.js'),productionLoop:true,nativeAdapter:true,storage,search:{v8SnipeMaximum:900,ratingRange:[10,99]},buy:{buyPrice:900,findBuyPrice:true,noOfCards:scenario.cards??10,skipClubPlayers:true},globals:{factories:{DataProvider:{getItemRarityDP:()=>scenario.metadata?.()??[{id:scenario.rarity??151,label:scenario.rarityName??'Fixture Native Rarity'}]}},ItemType:{PLAYER:'player'},SearchLevel:{ANY:'any'},Date:class extends RealDate{static now(){return virtualNow}},UTSearchCriteriaDTO:class{},repositories:{Rarity:{isCacheExpired:()=>scenario.metadataExpired??false},Item:{getUnassignedItems:()=>pages.flat().filter(item=>item._state.owned&&inventory.has(item.definitionId)),isPileFull:()=>scenario.inventoryFull??false}},URL,performance,queueMicrotask,setTimeout:(fn,ms,...args)=>setTimeout(fn,ms===15000&&scenario.fastTimeoutMs?scenario.fastTimeoutMs:ms,...args),clearTimeout,Promise,structuredClone,DEFAULT_PLAYSTYLE_ID:0,ItemSubType:{PLAYER:1,TRAINING_PLAYERSTYLE_GOALKEEPER_5:9},isPhone:()=>false,navigator:{locks:{request:async(name,opts,fn)=>fn({})}},fetch:async()=>({status:200}),XMLHttpRequest:class{open(){}send(){}}},installGuard:context=>{// RC MAIN-world guard. Closed by default; no saved setting creates a permit.
(()=>{
 'use strict';const symbol=Symbol.for('fcEnhancer.v8.executionGuard');if(globalThis[symbol])return;
 let blocked=0,claimed=false,grant=null,transport=null,insideService=false;const protectedServices=new WeakMap();
 const deny=()=>{blocked++;throw Error('FC v8 RC: purchase execution is disabled or the exact BIN permit is invalid')};
 const classify=(url,method)=>{const m=String(method||'GET').toUpperCase();if(['GET','HEAD','OPTIONS'].includes(m))return null;try{const path=new URL(String(url),globalThis.location?.href||'https://www.ea.com/').pathname;if(/\/auctionhouse(?:\/|$)/i.test(path))return{blocked:true};const match=path.match(/\/trade\/(\d+)\/bid\/?$/i);return match?{id:match[1],method:m}:/\/trade\/[^/]+\/bid(?:\/|$)/i.test(path)?{blocked:true}:null}catch{return{blocked:true}}};
 const checkTransport=(url,method,body)=>{const action=classify(url,method);if(!action){if((insideService||transport&&!transport.sent)&&!['GET','HEAD','OPTIONS'].includes(String(method||'GET').toUpperCase()))deny();return}const p=transport;if(action.blocked||!p||p.sent||action.method!=='PUT'||action.id!==p.id)deny();let value;try{value=JSON.parse(body)}catch{deny()}if(value?.bid!==p.price||Object.keys(value).length!==1)deny();p.verify();p.sent=true;};
 const installServices=(...targets)=>{try{for(const target of targets.filter(Boolean)){if(protectedServices.has(target))continue;const original=target.bid;if(typeof original!=='function')return false;const wrapped=function(item,price){const p=grant;if(!p||p.used||p.item!==item||p.price!==price)deny();p.consume(item,price);p.used=true;grant=null;transport=p;insideService=true;try{return original.apply(this,arguments)}finally{insideService=false}};Object.defineProperty(target,'bid',{get:()=>wrapped,set:()=>{},configurable:false});protectedServices.set(target,wrapped);}return targets.some(Boolean)}catch{return false}};
 if(typeof globalThis.fetch==='function'){const original=globalThis.fetch;globalThis.fetch=function(input,init){try{checkTransport(input?.url??input,init?.method??input?.method,init?.body)}catch(error){return Promise.reject(error)}return original.apply(this,arguments)}}
 if(typeof XMLHttpRequest!=='undefined'){const prototype=XMLHttpRequest.prototype,open=prototype.open,send=prototype.send,requests=new WeakMap();prototype.open=function(method,url){requests.set(this,{method,url});return open.apply(this,arguments)};prototype.send=function(body){const request=requests.get(this);if(request)checkTransport(request.url,request.method,body);return send.apply(this,arguments)}}
 const connect=()=>{if(claimed)return null;claimed=true;return Object.freeze({grant(item,price,consume,verify){const id=item?.getAuctionData?.()?.tradeId;if(!/^\d+$/.test(id)||!Number.isSafeInteger(price)||price<=0||typeof consume!=='function'||typeof verify!=='function')deny();const p={item,id,price,consume,verify,used:false,sent:false};grant=p;queueMicrotask(()=>{if(grant===p)grant=null})},revoke(){grant=null;transport=null}})};
 Object.defineProperty(globalThis,symbol,{value:Object.freeze({connect,installServices,isInstalled:()=>true,isServiceBlocked:target=>protectedServices.has(target)&&target.bid===protectedServices.get(target)&&!grant,blockedCount:()=>blocked,realPurchasingEnabled:false,mode:'final-release-default-disabled'}),configurable:false,writable:false});
})();
},transactionStubs:(store,services)=>{
 store.traderData.cache.cachedBids=new Set();store.traderData.cache.bidsByFilter=new Map();store.traderData.stats={purchasedCardCount:0,wonCount:0,lossCount:0,bidCount:0};store.traderSettings.safeSetting={maxPurchasesPerSearchRequest:scenario.perSearch??3,waitTime:[7,15],pauseCycle:[10,15],pauseFor:[5,8],stopAfter:[60,120]};store.traderSettings.sellSetting={sellPrice:[1000,1000],dontMoveWonItems:true};
 services.User={getUser:()=>({coins:{amount:coins}})};
 services.Item.bid=(item,price)=>observable(async()=>{attempts++;const start=performance.now();events.push({kind:'attempt',id:item._auction.tradeId,price,coinsBefore:coins});if(price>900||price!==item._auction.buyNowPrice)throw Error('Simulation price violation');const xhr=new h.context.XMLHttpRequest();xhr.open('PUT','https://example.invalid/ut/game/fc27/trade/'+item._auction.tradeId+'/bid');xhr.send(JSON.stringify({bid:price}));if(scenario.onSubmit)scenario.onSubmit({h,item});await wait(item._spec.delayMs??2);const success=item._spec.outcome!=='sold'&&item._spec.outcome!=='unknown'&&item._spec.outcome!=='malformed';if(success){if(item._spec.outcome!=='accepted-no-coins')coins-=price;if(item._spec.outcome!=='accepted-no-inventory'){item._state.owned=true;if(item._spec.outcome!=='accepted-missing-repository')inventory.add(item.definitionId)}}else if(item._spec.outcome==='sold')item._state.expired=true;events.push({kind:'result',id:item._auction.tradeId,success,coinsAfter:coins,elapsedMs:performance.now()-start});return item._spec.outcome==='malformed'?{success:'bad-protocol',data:null}:{success,error:success?undefined:{code:461}}});
 services.Item.refreshAuctions=items=>observable(async()=>{if(scenario.onRefresh)await scenario.onRefresh({h,items});await wait(1);return ['unknown','accepted-no-confirmation'].includes(items[0]._spec?.outcome)?{success:true,data:{malformed:true}}:{success:true,data:{itemIds:items.map(item=>item.id)}}});
 const stats=store.traderData.stats,noop=async(e,next)=>next(e);
 return{38014:{clearUnAssignedCache(){},getUnAssignedItems:async()=>({success:scenario.inventoryUnavailable!==true})},11890:{UTItemPileEnum:{INBOX:8}},27988:{getLocalization:()=>({localize:()=>''}),getNextStepValue:n=>n+50,getBeforeStepValue:n=>n-50,getNStepValue:(n,steps)=>n+(steps||0)*50,roundToNearestStep:n=>n,roundToNearestStepValue:n=>n},82125:{getRandomNumberInRange:(a,b)=>a??0,wait:async seconds=>{virtualNow+=seconds*1000},find:()=>null,NotificationEventPublisher:{instance:{notifyObservers(){}}}},22869:{ExternalNotificationType:{STOPPED:'STOPPED',STARTED:'STARTED',LOST:'LOST',WON:'WON',LISTED:'LISTED'},baseSettings:['buySetting','sellSetting','searchSetting'],sharedSettings:[]},39021:{StatsFactory:{instance:{getProcessor:()=>({incrementStat:k=>{stats[k]=(stats[k]||0)+1},getStats:()=>stats})}}},99611:{getBidPrice:()=>100},99398:{writeBuyPriceGreaterLog(){}},57439:{Analytics:{instance:{fireEvent(){}}}},41880:{updateErrorCodeCount(){}},19719:{bidErrorCodeLookup:{},errorCodeLookUp:{}},75946:{moveToClub:noop,moveToTransferList:noop,moveItem:noop},81139:{quickSellItem:noop},94607:{sellItem:noop},92659:{},26774:{},17790:{TimerFactory:{instance:{getTimer:fn=>({run:()=>{if(scenario.driveTimer)queueMicrotask(()=>fn());return 0},stop(){}})}}}};},augmentApi:api=>{api.getSquadPlayerIds=async()=>new Set(inventory)}});
 h.p.controllerInstance.viewmodel.searchCriteria={type:'player',rarities:[scenario.rarity??151],defId:[],maskedDefId:0,minBuy:0,maxBuy:0};
 h.context[Symbol.for('fcEnhancer.v8.executionGuard')].installServices(h.services.Item);
 h.p.traderSettings.sellSetting={sellPrice:[1000,1000],dontMoveWonItems:true};h.p.isStarted=false;h.p.isFirstRun=false;h.p.verifyUserAccess=()=>true;h.p.statsProcessor.start=()=>{};h.p.statsProcessor.updateStat=(k,v)=>{h.data.stats[k]=v};h.p.notifier.notify=()=>{};
 const orchestrator=new(h.get(51171).BackGroundTransferOrchestrator)();h.get(98003).TransferFactory.instance.getTransferOrchestrator=()=>orchestrator;
 const bridge=h.get(99012),metrics=h.get(99021);metrics.clear();
 const start=async({enable=true,budget=scenario.budget??4000}={})=>{if(enable){const armed=bridge.arm(h.p,{userEnabled:true,budget,minimumProfit:scenario.minimumProfit??25,additionalCosts:scenario.additionalCosts??0,maximumPerPurchase:scenario.maximumPerPurchase??900,maxPurchases:scenario.maxPurchases??10});if(!armed.response)throw Error('Unable to arm '+armed.reason)}await h.p.start()};
 const cycle=()=>h.cycle();const stop=()=>h.p.stop();
 return{...h,bridge,metrics,start,cycle,stop,journal,events,inventory,pages,attempts:()=>attempts,coins:()=>coins,summary:()=>({running:h.p.isStarted,status:bridge.status(h.p),attempts,coins,inventory:[...inventory],events,logs:h.logs,timings:metrics.snapshot()})};
};globalThis.__fcRc2CreateSession=createSession;
(function(){
 const logContainer=document.querySelector('.process-log-messages');const delayed=new URL(location.href).searchParams.has('delayed');if(delayed)logContainer.remove();
 const nativeStorage=globalThis.localStorage;const journal={get:key=>nativeStorage.getItem(key),set:(key,value)=>nativeStorage.setItem(key,value)};
 globalThis.__fcRenderLog=text=>{const row=document.createElement('div');row.className='message';row.textContent=text;logContainer.appendChild(row)};
 const base=Number(new URL(location.href).searchParams.get('run'))||2000;const h=globalThis.__fcRc2CreateSession({...(new URL(location.href).searchParams.get('scenario')==='market-error'?{marketError:{at:1,code:503}}:{}),bundle:'installed-UNIVERSAL',journal,followSelectedRarity:true,driveTimer:new URL(location.href).searchParams.has('nativeTimer'),metadata:()=>globalThis.__fcUniversalNativeRarities,pages:[[{id:base+1,player:201},{id:base+2,player:202,outcome:'sold'},{id:base+3,player:203,profitable:false},{id:base+4,price:901}],[{id:base+5,player:205}]]});
 globalThis.__fcRc2Session=h;
 h.p.setControllerInstance(h.p.controllerInstance);if(delayed)queueMicrotask(()=>document.body.appendChild(logContainer));
 const result=document.getElementById('simulation-result');const paint=()=>{const s=h.summary();result.textContent='Simulated coins '+s.coins+' · Inventory '+s.inventory.join(', ')+' · Attempts '+s.attempts;globalThis.__fcRc2Result=s;};
 document.getElementById('fixture-start').addEventListener('click',async()=>{try{await h.start({enable:false});for(let i=0;i<2&&h.p.isStarted;i++)await h.cycle();paint()}catch(error){console.error(error.message);result.textContent=error.message}});
 document.getElementById('fixture-stop').addEventListener('click',()=>{h.stop();paint()});
 const maximum=document.getElementById('fixture-maximum');maximum.addEventListener('change',()=>{h.settings.searchSetting.v8SnipeMaximum=Number(maximum.value);h.bridge.disarm(h.p,'configuration-changed');h.get(99011).refreshStatus(h.p);paint()});
 paint();document.documentElement.dataset.universalTestState='ready';
})();