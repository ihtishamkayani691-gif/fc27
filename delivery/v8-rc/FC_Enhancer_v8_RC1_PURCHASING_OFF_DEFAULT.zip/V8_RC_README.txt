FC Enhancer v8 RC1 (27.0.3.1)
Purchases are OFF by default and after Stop, errors, changes or reload. Saved filters cannot enable purchases. Disable every other FC Enhancer copy before loading this folder through chrome://extensions > Developer mode > Load unpacked.

This release candidate has not been verified with real transactions. Do not infer production readiness from mocks. Ultimate Scream discovery uses the existing native all-player method. To opt in for a later separately authorized run, configure your own positive maximum, enable native dynamic pricing and a native card-count budget, enter a positive RC run coin budget and explicitly check Enable purchases for next Trader run while stopped. There is no preset purchase ceiling. Native stricter prices and all existing checks still apply. Only the exact permitted BIN can pass the protected bid invocation; bids and auctionhouse listing mutations remain blocked. This guard is not a general firewall for all inventory actions.

Uncertain outcomes/timeouts persist a reconciliation lock. Stop/reload does not erase it. Do not clear the transaction journal to bypass uncertainty. There is intentionally no automatic unlock. Cross-tab execution uses browser Web Locks; unavailable storage/locks fail closed. No browser profile or credentials are included.

See delivery/v8-rc/ACCEPTANCE.md in the repository for evidence and remaining production limits. The historical V8_TEST_README describes the separate locked TEST build.
