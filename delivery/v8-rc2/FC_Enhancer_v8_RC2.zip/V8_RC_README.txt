FC Enhancer v8 RC2
Purchases default OFF after every reload. Configure your own maximum, native dynamic pricing/card limit and RC coin budget, then explicitly enable purchases for the run. Stop or Disable purchases now prevents new attempts. Unknown outcomes lock execution until native auction ownership and coin evidence agree; reconciliation never re-arms or retries.

RC2 is not verified with real transactions. Do not infer full market coverage or profitability from simulation. Keep other FC Enhancer copies disabled in the same profile. See delivery/v8-rc2/ACCEPTANCE.md in the repository.
