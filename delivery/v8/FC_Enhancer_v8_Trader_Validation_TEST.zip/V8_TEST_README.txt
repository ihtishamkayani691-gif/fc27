FC Enhancer v8 reliability TEST (27.0.2.2)

Extract the ZIP to a permanent folder. In Chrome, open chrome://extensions, enable Developer mode, and choose Load unpacked for the folder containing manifest.json. Disable older FC Enhancer copies in that Chrome profile before loading this TEST copy.

Real buying and bidding are locked in the build policy and service/transport guards. This TEST cannot authorize purchases. Any displayed validation ceilings, including 100,000 coins, are test settings and are not your purchase instructions. Set your own maximum explicitly for any permitted discovery session; zero/missing maximum prevents v8 discovery.

Use the native Ultimate Scream rarity with no individual player selected. Trader displays rarity, configured/effective maximum, fresh candidates, rejected candidates and execution status. Existing native checks remain in the preview path. Fresh-window duration does not prove listing creation time or profitability.

This is not a production-ready automatic purchaser. Exhaustive pool coverage and real transaction behavior remain unproven. Separate authorization and further validation are required before any future purchase-enabled build. Unknown outcomes require native-state reconciliation, never automatic retry.

See delivery/v8/ACCEPTANCE.md in the development repository for evidence. Older included README files describe historical versions; this file governs the v8 TEST build.
