'use strict';
(async()=>{
 const checks=[],stubs={},cache=new Map(),allowed=new Set([99008,99009,99010,51477,72316,93727,39887,10270,30804]);
 const assert=(name,condition,detail)=>{checks.push({name,passed:!!condition,detail});if(!condition)throw Error(name)};
 const loadModule=id=>{id=Number(id);if(Object.hasOwn(stubs,id))return stubs[id];if(cache.has(id))return cache.get(id).exports;if(!allowed.has(id))throw Error('Forbidden offline module '+id);const m={exports:{}};cache.set(id,m);globalThis.__fcProductionFactories[id](m,m.exports,loadModule);return m.exports;};
 const deny=()=>{throw Error('Offline extension fixture forbids network')};globalThis.fetch=deny;globalThis.XMLHttpRequest=class{constructor(){deny()}};globalThis.WebSocket=class{constructor(){deny()}};
 try{await (async function({loadModule,assert,stubs,document,window}){
 window.DEFAULT_PLAYSTYLE_ID=0;window.ItemSubType={TRAINING_PLAYERSTYLE_GOALKEEPER_5:9};
 stubs[26735]={UINotificationTypeEnum:{POSITIVE:1,NEGATIVE:2,NEUTRAL:3}};
 stubs[82125]={getCurrentTimeString:()=> '00:00:00',find:selector=>document.querySelector(selector),htmlToElement:html=>{const t=document.createElement('template');t.innerHTML=html.trim();return t.content.firstElementChild}};
 stubs[32024]={InMemoryStore:{instance:{get:()=>({commonSetting:{showMilliSecond:false,logTypes:['ALL']}})}}};
 stubs[27988]={getLocalization:()=>({localizeNumber:String,localizeAuctionTimeRemaining:String})};
 stubs[22869]={TraderLogType:{ALL:'ALL',INFO:'INFO',WARN:'WARN',ERROR:'ERROR',SUCCESS:'SUCCESS'}};
 stubs[44669]={translate:key=>key};stubs[99398]={writeBuyPriceGreaterLog(){}};
 const {OfflineIntegration}=loadModule(99008);
 const session=new OfflineIntegration({criteria:{type:'player',rarities:[4242]},verifiedRarityIds:[4242],snipeMaximum:900});
 const auction={tradeId:'900000000000000001',buyNowPrice:700,expires:3559,isExpired:()=>false};
 const item={_auction:auction,rating:85,preferredPosition:1,playStyle:1,getAuctionData:()=>auction,getStaticData:()=>({name:'Synthetic <Alpha>'})};
 const settings={buySetting:{buyPrice:900,findBuyPrice:false},searchSetting:{ratingRange:[10,99]}},data={cache:{cachedBids:new Set()}};
 const replay=()=>session.replay({intentId:session.next().id,items:[item],settings,data,safetyOptions:{balance:10000}});
 const result=await replay();
 assert('bundled v8 planner and native safety evaluate synthetic item',result.records[0].safety.status==='pass',JSON.stringify(result.records[0].safety));
 assert('v8 integration cannot authorize purchase',result.purchaseAuthorized===false&&result.records[0].safety.purchaseAuthorized===false&&data.cache.cachedBids.size===0);
 const duplicate=await replay();assert('v8 integration deduplicates repeated trade IDs',duplicate.records.length===0);
 await new Promise(resolve=>window.setTimeout(resolve,100));
 const message=document.querySelector('.process-log-messages .message');
 assert('integrated v8 output reaches the production Trader logger',message?.textContent.includes('[v8 OFFLINE]')&&message.textContent.includes('buying=DISABLED'));
 assert('integrated player display text is escaped',message.textContent.includes('Synthetic <Alpha>')&&message.querySelector('alpha')===null);
 session.stop();assert('stopped integration produces no further intents',session.next()===null);
 assert('offline integration reports incomplete live coverage',result.diagnostics.coverageComplete===false&&result.liveDiscoveryProven===false);
})({loadModule,assert,stubs,document,window});globalThis.__fcInstalledIntegrationResult={checks,liveEA:false,purchaseAuthorized:false};document.documentElement.dataset.testState='passed';document.getElementById('status').textContent=checks.length+' checks passed. No market requests.';}
 catch(error){document.documentElement.dataset.testState='failed';document.getElementById('status').textContent=error.message;throw error;}
 finally{for(const check of checks){const row=document.createElement('li');row.textContent=(check.passed?'PASS: ':'FAIL: ')+check.name;document.getElementById('checks').appendChild(row);}}
})();
;(()=>{const api={};globalThis.__fcProductionFactories[99015]({},api,()=>{throw Error('No status dependencies')});const panel=api.createStatusPanel(document);panel.mount();panel.update({state:'stopped',rarityLabel:'Synthetic fixture rarity',rarityIds:[4242],configuredMaximum:900,effectiveMaximum:800,freshCount:1,rejectedCount:2,rejectionReasons:{'Outside price limits':2},freshCandidates:[{name:'Synthetic <Player>',buyNowPrice:700}]});})();
